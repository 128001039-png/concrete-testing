import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// Initialize Gemini SDK with telemetry header according to guidelines
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// System instruction for Ask ConcreteIQ
const SYSTEM_INSTRUCTION = `You are ConcreteIQ, an expert Civil Engineering Intelligence Assistant designed for a B.Tech Civil Engineering Data Analytics laboratory project (Experiment No. 11: Machine Learning Analytics for Concrete Compressive Strength).

Your capabilities & core domains:
1. Concrete Materials Science: Portland cement hydration, C-S-H gel, calcium hydroxide, blast furnace slag (GGBS latent hydraulicity), fly ash (pozzolanic reactivity, Class F/C), water-cementitious ratio (Abrams' law), superplasticizers (polycarboxylate ether / steric hindrance), coarse aggregate interlocking, sand fineness modulus.
2. Machine Learning for Civil Engineering: Random Forest regression, decision trees, variance reduction (MSE split criterion), bagging, out-of-bag error, train/test splitting (80/20), prevention of target leakage, evaluation metrics:
   - R² (Coefficient of Determination): Proportion of variance in compressive strength explained by the mix parameters.
   - MAE (Mean Absolute Error): Average magnitude of prediction errors in MPa.
   - RMSE (Root Mean Square Error): Penalizes larger prediction deviations in MPa.
   - Residual Analysis: Measured vs. predicted scatter, homoscedasticity, and outliers.
3. Concrete Mix Design Principles: ACI 211.1, IS 10262, IS 456, target mean strength, exposure classes, minimum cement content, maximum w/c ratio, workability (slump testing).
4. Academic Laboratory Context: Experiment No. 11, Data Analytics for Civil Engineering, UCI Concrete Compressive Strength dataset (1,030 specimens, 8 input variables, Prof. I-Cheng Yeh).

Guidelines:
- Deliver articulate, structured, professional, and accessible answers suitable for university engineering demonstrations and student laboratory vivas.
- Distinguish clearly between empirical ML predictions and established physical/chemical codes.
- State appropriate technical units (MPa, kg/m³, days, mm).
- Always include an engineering disclaimer reminding that laboratory trial mixes, workability checks, and specimen cube crushing tests are non-negotiable before practical casting.`;

// Curated civil engineering fallback responses when API key is unavailable
function getKnowledgeBaseResponse(query: string): string {
  const q = query.toLowerCase();

  if (q.includes('rmse') || q.includes('root mean square')) {
    return `### Understanding Root Mean Square Error (RMSE) in Concrete Strength Prediction

In concrete compressive strength modeling, **RMSE** is defined mathematically as:
$$\\text{RMSE} = \\sqrt{\\frac{1}{n} \\sum_{i=1}^{n} (y_i - \\hat{y}_i)^2}$$

#### Why RMSE Matters for Civil Engineers:
1. **Penalizes Outliers**: Because errors are squared before averaging, RMSE heavily penalizes large prediction errors (e.g., an error of 12 MPa is penalized 4× more than an error of 6 MPa). In structural design, a mix that is unexpectedly weak is catastrophic, making RMSE the safety-critical metric.
2. **Same Physical Units**: Unlike mean squared error (MSE), RMSE is expressed in **MPa** (megapascals), directly comparable to laboratory cylinder/cube compressive strength ratings.
3. **Typical Benchmark**: For the UCI Concrete dataset (range 2.3 to 82.6 MPa), our Random Forest model achieves an RMSE of approximately **5.5 to 7.2 MPa**, which corresponds to standard laboratory batching coefficient of variation ($\sim 10-12\\%$).

*Note: Model evaluations must always be validated against standard 28-day water-cured cube compressive test trials.*`;
  }

  if (q.includes('water') || q.includes('w/c') || q.includes('water-cement') || q.includes('ratio')) {
    return `### The Engineering Criticality of Mixing Water Content

Water plays a dual and conflicting role in concrete technology:

1. **Hydration Kinetics**: Water is chemically required for the hydration of calcium silicates ($C_3S$ and $C_2S$) to produce calcium silicate hydrate ($C\\text{-}S\\text{-}H$) gel and calcium hydroxide ($Ca(OH)_2$). Stoichiometrically, only about **0.23 to 0.28 kg of water per kg of cement** is chemically consumed, with an additional **0.15** bound in gel pores.
2. **Abrams' Law ($f_c = \\frac{A}{B^{w/c}}$)**: Compressive strength is inversely related to the water-to-cement ratio ($w/c$). Any water added beyond the hydration requirement evaporates or remains in capillary pores, creating voids that drastically reduce compressive strength and increase permeability.
3. **Workability vs. Strength Dilemma**: Historically, extra water was added to increase slump for ease of placing and compaction. Modern mix design resolves this trade-off using **superplasticizers** (polycarboxylate ethers), which disperse cement particles electrostatically, permitting low $w/c$ ratios ($0.30 - 0.45$) while achieving high workability (>100 mm slump).`;
  }

  if (q.includes('correlation') || q.includes('heatmap') || q.includes('features')) {
    return `### Interpreting the Concrete Correlation Heatmap

Our laboratory data analytics reveals the following key linear and non-linear relationships across the 1,030 UCI concrete specimens:

1. **Cement vs. Compressive Strength ($r \\approx +0.50$)**: Strong positive correlation. Increasing cement paste increases the volume fraction of load-bearing C-S-H gel.
2. **Curing Age vs. Strength ($r \\approx +0.33$)**: Consistent positive correlation across logarithmic time scale (1, 3, 7, 14, 28, 56, 90, 365 days). The steepest gain occurs between day 1 and 28.
3. **Water vs. Strength ($r \\approx -0.29$)**: Negative correlation, corroborating Abrams' water-cement ratio law. High water content dilutes paste density and induces capillary porosity.
4. **Superplasticizer vs. Water ($r \\approx -0.66$)**: Strong inverse correlation. Illustrates that modern high-performance concrete mixes leverage superplasticizers specifically to reduce mixing water demand while preserving workability.
5. **Fly Ash & Slag Interactions**: Show moderate negative correlation with early-age strength, but positive correlation with late-age (56+ day) durability and strength gain.`;
  }

  if (q.includes('validate') || q.includes('trial mix') || q.includes('testing')) {
    return `### Laboratory Validation Protocol for Concrete Mix Designs

Before utilizing any computer-generated mix in structural construction, standard engineering practice (IS 10262, IS 456, ACI 211) mandates this 5-stage validation sequence:

1. **Material Characterization**:
   - Sieve analysis of coarse aggregate (20mm, 10mm) and fine aggregate (Zone II / III).
   - Specific gravity, water absorption, and moisture content determination.
   - Cement standard consistency and 53-grade / 43-grade compliance.
2. **Laboratory Trial Batches**:
   - Cast a trial batch of $0.05 \\text{ m}^3$ in a laboratory pan mixer.
   - Conduct fresh concrete testing: **Slump test** (IS 1199), compaction factor, and fresh unit weight.
   - Verify non-segregation and absence of excessive bleed water.
3. **Specimen Casting & Standard Curing**:
   - Cast minimum nine $150 \\times 150 \\times 150 \\text{ mm}$ standard cubes (or $150 \\times 300 \\text{ mm}$ cylinders).
   - Demould after 24 hours and submerge in temperature-controlled curing tanks ($27 \\pm 2^\\circ\\text{C}$).
4. **Compression Testing Machine (CTM)**:
   - Crush 3 cubes at 3 days, 3 cubes at 7 days, and 3 cubes at 28 days under a calibrated loading rate ($140 \\text{ kg/cm}^2/\\text{min}$).
   - Compare actual mean strength against target design strength ($f'_{ck} = f_{ck} + 1.65\\sigma$).
5. **Admixture Compatibility Check**: Verify no flash set or delayed setting due to chemical incompatibility between cement tricalcium aluminate ($C_3A$) and polycarboxylate ether superplasticizer.`;
  }

  return `### ConcreteIQ Civil Engineering Analysis

Regarding **${query.replace(/[*#]/g, '').trim()}**:

In concrete technology and predictive materials analytics:
1. **Hydraulic Binder Kinetics**: Compressive strength is governed by the volume of solid hydration products ($C\\text{-}S\\text{-}H$ gel) relative to the space available (gel-space ratio). Cement, blast furnace slag, and fly ash collectively provide the binder matrix.
2. **Machine Learning Perspective**: The Random Forest regressor captures complex, non-linear interactions between multi-binder combinations, aggregate grading skeletons, and water dosage that single-variable regression equations cannot model.
3. **Verification Requirement**: While machine learning predictions provide exceptional exploratory insight (R² $\\approx 0.80 - 0.88$), actual structural concrete must always be verified through physical laboratory trial mixes, slump tests, and standard 28-day water-cured cube crushing according to IS 10262 and IS 456 standards.`;
}

// API endpoint for Ask ConcreteIQ chat
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required.' });
      return;
    }

    // If Gemini client is initialized, call Gemini 3.8 Flash
    if (ai) {
      try {
        const contents: any[] = [];
        
        // Add past turns if provided
        if (Array.isArray(history)) {
          for (const item of history.slice(-6)) {
            contents.push({
              role: item.role === 'user' ? 'user' : 'model',
              parts: [{ text: item.content }],
            });
          }
        }

        // Add current user prompt
        contents.push({
          role: 'user',
          parts: [{ text: message }],
        });

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.3,
          },
        });

        const text = response.text || '';
        res.json({ reply: text, source: 'gemini-3.8-flash' });
        return;
      } catch (geminiError: any) {
        console.warn('Gemini API call failed, falling back to engineering knowledge base:', geminiError?.message);
      }
    }

    // Fallback response from civil engineering knowledge base
    const fallbackReply = getKnowledgeBaseResponse(message);
    res.json({ reply: fallbackReply, source: 'concreteiq-knowledge-base' });
  } catch (err: any) {
    console.error('Chat endpoint error:', err);
    res.status(500).json({ error: 'Failed to process chat query.' });
  }
});

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'ConcreteIQ Civil Analytics Engine',
    geminiActive: !!ai,
    timestamp: new Date().toISOString(),
  });
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`CONCRETEIQ server listening on http://0.0.0.0:${port} [${isProduction ? 'production' : 'development'}]`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
