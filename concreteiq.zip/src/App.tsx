/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import initialDataset from './data/concrete_dataset.json';
import { ConcreteSample, HistoryItem, MixInput, ModelMetrics, PredictionResult } from './types/concrete';
import { RandomForestRegressor } from './ml/randomForest';
import { Navbar, NavTab } from './components/Navbar';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { Hero } from './components/Hero';
import { DashboardOverview } from './components/DashboardOverview';
import { StrengthPredictor } from './components/StrengthPredictor';
import { DataExplorer } from './components/DataExplorer';
import { MixDesignAssistant } from './components/MixDesignAssistant';
import { AskAssistant } from './components/AskAssistant';
import { PredictionHistory } from './components/PredictionHistory';
import { AboutProject } from './components/AboutProject';

const STORAGE_KEY_HISTORY = 'concreteiq_prediction_history_v1';
const STORAGE_KEY_THEME = 'concreteiq_theme_pref';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [dataset, setDataset] = useState<ConcreteSample[]>(initialDataset as ConcreteSample[]);
  const [isDark, setIsDark] = useState<boolean>(true);
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [latestPrediction, setLatestPrediction] = useState<PredictionResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  // Initialize theme from storage
  useEffect(() => {
    const savedTheme = localStorage.getItem(STORAGE_KEY_THEME);
    if (savedTheme === 'light') {
      setIsDark(false);
      document.documentElement.classList.remove('dark');
    } else {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
        localStorage.setItem(STORAGE_KEY_THEME, 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem(STORAGE_KEY_THEME, 'light');
      }
      return next;
    });
  };

  // Initialize prediction history from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_HISTORY);
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch (e) {
      console.warn('Failed to parse history from localStorage', e);
    }
  }, []);

  // Sync history to localStorage
  const saveHistoryToStorage = (updatedHistory: HistoryItem[]) => {
    setHistory(updatedHistory);
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updatedHistory));
    } catch (e) {
      console.warn('Failed to save history to localStorage', e);
    }
  };

  // ML Model instance
  const [modelConfig, setModelConfig] = useState({
    nTrees: 45,
    maxDepth: 11,
    testSplitRatio: 0.2,
    seed: 42,
  });

  const model = useMemo(() => {
    return new RandomForestRegressor(
      modelConfig.nTrees,
      modelConfig.maxDepth,
      4,
      modelConfig.testSplitRatio,
      modelConfig.seed
    );
  }, [modelConfig]);

  // Train model on current dataset
  const [metrics, setMetrics] = useState<ModelMetrics>(() => {
    return model.train(dataset);
  });

  // Retrain handler
  const handleRetrain = useCallback(
    (newConfig: { nTrees: number; maxDepth: number; testSplitRatio: number; seed: number }) => {
      setIsTraining(true);
      setModelConfig(newConfig);
      setTimeout(() => {
        try {
          const freshModel = new RandomForestRegressor(
            newConfig.nTrees,
            newConfig.maxDepth,
            4,
            newConfig.testSplitRatio,
            newConfig.seed
          );
          const freshMetrics = freshModel.train(dataset);
          setMetrics(freshMetrics);
        } catch (err) {
          console.error('Error retraining model:', err);
        } finally {
          setIsTraining(false);
        }
      }, 50);
    },
    [dataset]
  );

  // Predict handler
  const handlePredict = async (input: MixInput): Promise<PredictionResult> => {
    const res = model.predict(input);
    setLatestPrediction(res);
    return res;
  };

  // Save to history
  const handleSaveToHistory = (result: PredictionResult, name: string, notes?: string) => {
    const newItem: HistoryItem = {
      id: `mix_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: name || 'Custom Mix',
      timestamp: new Date().toISOString(),
      input: { ...result.input },
      result: { ...result },
      notes,
    };
    const updated = [newItem, ...history];
    saveHistoryToStorage(updated);
  };

  // Delete history item
  const handleDeleteHistory = (id: string) => {
    const updated = history.filter((h) => h.id !== id);
    saveHistoryToStorage(updated);
  };

  // Clear all history
  const handleClearAllHistory = () => {
    saveHistoryToStorage([]);
  };

  // Transfer from Mix Design Assistant
  const handleTransferToPredictor = (input: MixInput) => {
    // When transferring, we trigger prediction on the transfer mix
    const pred = model.predict(input);
    setLatestPrediction(pred);
  };

  // Custom dataset upload
  const handleUploadDataset = (newSamples: ConcreteSample[]) => {
    setDataset(newSamples);
    setIsTraining(true);
    setTimeout(() => {
      try {
        const freshMetrics = model.train(newSamples);
        setMetrics(freshMetrics);
      } catch (err) {
        console.error('Error retraining with custom dataset:', err);
      } finally {
        setIsTraining(false);
      }
    }, 50);
  };

  // Reset to canonical UCI dataset
  const handleResetOfficialDataset = () => {
    setDataset(initialDataset as ConcreteSample[]);
    setIsTraining(true);
    setTimeout(() => {
      try {
        const freshMetrics = model.train(initialDataset as ConcreteSample[]);
        setMetrics(freshMetrics);
      } catch (err) {
        console.error('Error resetting dataset:', err);
      } finally {
        setIsTraining(false);
      }
    }, 50);
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900 light'}`}>
      {/* 1. Global Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDark={isDark}
        toggleTheme={toggleTheme}
      />

      {/* 2. Mandatory Engineering Safety Notice Banner */}
      <DisclaimerBanner />

      {/* 3. Hero Section (renders on Overview or as top anchor) */}
      {activeTab === 'overview' && (
        <Hero
          onNavigate={setActiveTab}
          latestPrediction={latestPrediction}
        />
      )}

      {/* 4. Main Application Workspace Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'overview' && (
          <DashboardOverview
            metrics={metrics}
            onRetrain={handleRetrain}
            isTraining={isTraining}
            latestPrediction={latestPrediction}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'predictor' && (
          <StrengthPredictor
            onPredict={handlePredict}
            onSaveToHistory={handleSaveToHistory}
            onNavigate={setActiveTab}
            initialPrediction={latestPrediction}
          />
        )}

        {activeTab === 'explorer' && (
          <DataExplorer
            dataset={dataset}
            onUploadDataset={handleUploadDataset}
            onResetOfficialDataset={handleResetOfficialDataset}
          />
        )}

        {activeTab === 'mix-design' && (
          <MixDesignAssistant
            onTransferToPredictor={handleTransferToPredictor}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'assistant' && <AskAssistant />}

        {activeTab === 'history' && (
          <PredictionHistory
            history={history}
            onDelete={handleDeleteHistory}
            onClearAll={handleClearAllHistory}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'about' && <AboutProject />}
      </main>

      {/* 5. Professional Engineering Footer */}
      <footer className="border-t border-slate-800 bg-slate-950/80 text-xs text-slate-400 py-6 mt-12 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-200">CONCRETEIQ</span>
            <span className="opacity-40">·</span>
            <span>B.Tech Civil Engineering Data Analytics Lab</span>
            <span className="opacity-40">·</span>
            <span>Exp. No. 11</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>UCI Concrete Compressive Strength Repository</span>
            <span className="opacity-40">·</span>
            <span>Random Forest Regressor (R² = {metrics.r2})</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
