import { ConcreteSample, FeatureKey, MixInput, ModelMetrics, PredictionResult } from '../types/concrete';

const FEATURE_KEYS: FeatureKey[] = [
  'cement',
  'slag',
  'flyAsh',
  'water',
  'superplasticizer',
  'coarseAggregate',
  'fineAggregate',
  'age',
];

const FEATURE_NAMES: Record<FeatureKey, string> = {
  cement: 'Cement',
  slag: 'Blast Furnace Slag',
  flyAsh: 'Fly Ash',
  water: 'Water',
  superplasticizer: 'Superplasticizer',
  coarseAggregate: 'Coarse Aggregate',
  fineAggregate: 'Fine Aggregate',
  age: 'Curing Age',
};

// Seeded PRNG (Mulberry32) for reproducible training & bootstrap sampling
function createRng(seed: number) {
  let s = Math.floor(seed) >>> 0;
  return function () {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface TreeNode {
  featureIdx: number; // -1 if leaf
  threshold: number;
  value: number;
  left: TreeNode | null;
  right: TreeNode | null;
}

class DecisionTreeRegressor {
  root: TreeNode | null = null;
  maxDepth: number;
  minSamplesSplit: number;
  minSamplesLeaf: number;
  featureSubsampleSize: number;

  constructor(
    maxDepth = 10,
    minSamplesSplit = 4,
    minSamplesLeaf = 2,
    featureSubsampleSize = 4
  ) {
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
    this.minSamplesLeaf = minSamplesLeaf;
    this.featureSubsampleSize = featureSubsampleSize;
  }

  train(
    X: number[][],
    y: number[],
    rng: () => number,
    featureImportances: number[]
  ) {
    const indices = Array.from({ length: X.length }, (_, i) => i);
    this.root = this.buildNode(X, y, indices, 0, rng, featureImportances);
  }

  private buildNode(
    X: number[][],
    y: number[],
    indices: number[],
    depth: number,
    rng: () => number,
    featureImportances: number[]
  ): TreeNode {
    const n = indices.length;
    let sum = 0;
    for (let i = 0; i < n; i++) sum += y[indices[i]];
    const mean = sum / n;

    // Check leaf condition
    if (depth >= this.maxDepth || n < this.minSamplesSplit) {
      return {
        featureIdx: -1,
        threshold: 0,
        value: mean,
        left: null,
        right: null,
      };
    }

    // Node variance
    let varianceSum = 0;
    for (let i = 0; i < n; i++) {
      const diff = y[indices[i]] - mean;
      varianceSum += diff * diff;
    }
    const currentImpurity = varianceSum / n;

    if (currentImpurity < 1e-4) {
      return {
        featureIdx: -1,
        threshold: 0,
        value: mean,
        left: null,
        right: null,
      };
    }

    // Subsample features (Random Forest feature randomization)
    const numFeatures = X[0].length;
    const availableFeatures = Array.from({ length: numFeatures }, (_, i) => i);
    // Fisher-Yates shuffle subset
    for (let i = 0; i < this.featureSubsampleSize; i++) {
      const r = i + Math.floor(rng() * (numFeatures - i));
      const temp = availableFeatures[i];
      availableFeatures[i] = availableFeatures[r];
      availableFeatures[r] = temp;
    }
    const chosenFeatures = availableFeatures.slice(0, this.featureSubsampleSize);

    let bestFeature = -1;
    let bestThreshold = 0;
    let bestGain = -Infinity;
    let bestLeftIndices: number[] = [];
    let bestRightIndices: number[] = [];

    for (const fIdx of chosenFeatures) {
      // Collect values and sort unique candidates
      const vals: number[] = [];
      for (let i = 0; i < n; i++) {
        vals.push(X[indices[i]][fIdx]);
      }
      vals.sort((a, b) => a - b);

      // Candidate split percentiles / steps
      const numSteps = Math.min(12, vals.length - 1);
      const stepSize = Math.max(1, Math.floor(vals.length / numSteps));

      for (let s = 1; s <= numSteps; s++) {
        const splitIdx = Math.min(s * stepSize, vals.length - 1);
        const threshold = (vals[splitIdx - 1] + vals[splitIdx]) / 2;

        if (threshold === vals[splitIdx]) continue;

        let leftCount = 0;
        let rightCount = 0;
        let leftSum = 0;
        let rightSum = 0;

        for (let i = 0; i < n; i++) {
          const idx = indices[i];
          const val = X[idx][fIdx];
          const target = y[idx];
          if (val <= threshold) {
            leftCount++;
            leftSum += target;
          } else {
            rightCount++;
            rightSum += target;
          }
        }

        if (leftCount < this.minSamplesLeaf || rightCount < this.minSamplesLeaf) {
          continue;
        }

        const leftMean = leftSum / leftCount;
        const rightMean = rightSum / rightCount;

        let leftVar = 0;
        let rightVar = 0;

        for (let i = 0; i < n; i++) {
          const idx = indices[i];
          const target = y[idx];
          if (X[idx][fIdx] <= threshold) {
            leftVar += (target - leftMean) * (target - leftMean);
          } else {
            rightVar += (target - rightMean) * (target - rightMean);
          }
        }

        const splitImpurity = (leftVar + rightVar) / n;
        const gain = currentImpurity - splitImpurity;

        if (gain > bestGain) {
          bestGain = gain;
          bestFeature = fIdx;
          bestThreshold = threshold;
        }
      }
    }

    if (bestGain <= 1e-4 || bestFeature === -1) {
      return {
        featureIdx: -1,
        threshold: 0,
        value: mean,
        left: null,
        right: null,
      };
    }

    // Partition indices
    for (let i = 0; i < n; i++) {
      const idx = indices[i];
      if (X[idx][bestFeature] <= bestThreshold) {
        bestLeftIndices.push(idx);
      } else {
        bestRightIndices.push(idx);
      }
    }

    if (bestLeftIndices.length < this.minSamplesLeaf || bestRightIndices.length < this.minSamplesLeaf) {
      return {
        featureIdx: -1,
        threshold: 0,
        value: mean,
        left: null,
        right: null,
      };
    }

    // Accumulate impurity gain for feature importance
    featureImportances[bestFeature] += bestGain * (n / X.length);

    const leftChild = this.buildNode(X, y, bestLeftIndices, depth + 1, rng, featureImportances);
    const rightChild = this.buildNode(X, y, bestRightIndices, depth + 1, rng, featureImportances);

    return {
      featureIdx: bestFeature,
      threshold: bestThreshold,
      value: mean,
      left: leftChild,
      right: rightChild,
    };
  }

  predictSample(sample: number[]): number {
    let curr = this.root;
    while (curr && curr.featureIdx !== -1) {
      if (sample[curr.featureIdx] <= curr.threshold) {
        curr = curr.left;
      } else {
        curr = curr.right;
      }
    }
    return curr ? curr.value : 0;
  }
}

export class RandomForestRegressor {
  trees: DecisionTreeRegressor[] = [];
  nTrees: number;
  maxDepth: number;
  minSamplesSplit: number;
  testSplitRatio: number;
  seed: number;
  metrics: ModelMetrics | null = null;

  constructor(
    nTrees = 45,
    maxDepth = 11,
    minSamplesSplit = 4,
    testSplitRatio = 0.2,
    seed = 42
  ) {
    this.nTrees = nTrees;
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
    this.testSplitRatio = testSplitRatio;
    this.seed = seed;
  }

  train(samples: ConcreteSample[]): ModelMetrics {
    if (samples.length < 50) {
      throw new Error('Dataset contains insufficient samples for training (minimum 50 required).');
    }

    const rng = createRng(this.seed);

    // 1. Convert samples to feature matrix X and target vector y
    const X: number[][] = [];
    const y: number[] = [];

    for (const s of samples) {
      X.push([
        s.cement,
        s.slag,
        s.flyAsh,
        s.water,
        s.superplasticizer,
        s.coarseAggregate,
        s.fineAggregate,
        s.age,
      ]);
      y.push(s.strength);
    }

    // 2. Train/Test Split (stratified-like deterministic random shuffle)
    const indices = Array.from({ length: samples.length }, (_, i) => i);
    for (let i = indices.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      const tmp = indices[i];
      indices[i] = indices[j];
      indices[j] = tmp;
    }

    const testSize = Math.floor(samples.length * this.testSplitRatio);
    const testIndices = indices.slice(0, testSize);
    const trainIndices = indices.slice(testSize);

    const X_train = trainIndices.map((i) => X[i]);
    const y_train = trainIndices.map((i) => y[i]);
    const X_test = testIndices.map((i) => X[i]);
    const y_test = testIndices.map((i) => y[i]);

    // 3. Train Ensemble with Bagging
    this.trees = [];
    const rawFeatureImportances = new Array(FEATURE_KEYS.length).fill(0);
    const nTrain = X_train.length;

    for (let t = 0; t < this.nTrees; t++) {
      // Bootstrap sample (with replacement)
      const bootIndices: number[] = [];
      for (let b = 0; b < nTrain; b++) {
        bootIndices.push(Math.floor(rng() * nTrain));
      }

      const bootX = bootIndices.map((i) => X_train[i]);
      const bootY = bootIndices.map((i) => y_train[i]);

      const tree = new DecisionTreeRegressor(
        this.maxDepth,
        this.minSamplesSplit,
        2,
        Math.max(2, Math.floor(Math.sqrt(FEATURE_KEYS.length)))
      );
      tree.train(bootX, bootY, rng, rawFeatureImportances);
      this.trees.push(tree);
    }

    // 4. Test Set Evaluation
    const testPredictions: { actual: number; predicted: number; residual: number }[] = [];
    let sumAbsError = 0;
    let sumSqError = 0;
    let testSum = 0;

    for (let i = 0; i < X_test.length; i++) {
      const sample = X_test[i];
      const actual = y_test[i];
      testSum += actual;

      // Predict sample across all trees
      let treeSum = 0;
      for (const tree of this.trees) {
        treeSum += tree.predictSample(sample);
      }
      const pred = Math.round((treeSum / this.trees.length) * 100) / 100;
      const residual = Math.round((actual - pred) * 100) / 100;

      testPredictions.push({ actual, predicted: pred, residual });
      sumAbsError += Math.abs(actual - pred);
      sumSqError += (actual - pred) * (actual - pred);
    }

    const testMean = testSum / X_test.length;
    let totalSumSq = 0;
    for (let i = 0; i < X_test.length; i++) {
      totalSumSq += (y_test[i] - testMean) * (y_test[i] - testMean);
    }

    // R^2, MAE, RMSE calculation
    const r2 = Math.max(0, Math.min(0.999, 1 - sumSqError / (totalSumSq || 1)));
    const mae = sumAbsError / X_test.length;
    const rmse = Math.sqrt(sumSqError / X_test.length);

    // Normalize feature importances
    const totalImp = rawFeatureImportances.reduce((a, b) => a + b, 0) || 1;
    const featureImportances = FEATURE_KEYS.map((key, idx) => ({
      key,
      label: FEATURE_NAMES[key],
      importance: Math.round((rawFeatureImportances[idx] / totalImp) * 1000) / 1000,
    })).sort((a, b) => b.importance - a.importance);

    this.metrics = {
      r2: Math.round(r2 * 1000) / 1000,
      mae: Math.round(mae * 100) / 100,
      rmse: Math.round(rmse * 100) / 100,
      trainSampleCount: X_train.length,
      testSampleCount: X_test.length,
      totalSampleCount: samples.length,
      featureImportances,
      testPredictions,
      trainedAt: new Date().toISOString(),
      config: {
        nTrees: this.nTrees,
        maxDepth: this.maxDepth,
        minSamplesSplit: this.minSamplesSplit,
        testSplitRatio: this.testSplitRatio,
        seed: this.seed,
      },
    };

    return this.metrics;
  }

  predict(input: MixInput): PredictionResult {
    if (this.trees.length === 0) {
      throw new Error('Model has not been trained yet.');
    }

    const sample = [
      input.cement,
      input.slag,
      input.flyAsh,
      input.water,
      input.superplasticizer,
      input.coarseAggregate,
      input.fineAggregate,
      input.age,
    ];

    const predictions: number[] = [];
    for (const tree of this.trees) {
      predictions.push(tree.predictSample(sample));
    }

    const sum = predictions.reduce((a, b) => a + b, 0);
    const mean = sum / predictions.length;

    // Variance between trees
    const variance =
      predictions.reduce((acc, p) => acc + (p - mean) * (p - mean), 0) /
      Math.max(1, predictions.length - 1);
    const uncertaintyStd = Math.sqrt(variance);

    const lower95 = Math.max(0, Math.round((mean - 1.96 * uncertaintyStd) * 10) / 10);
    const upper95 = Math.round((mean + 1.96 * uncertaintyStd) * 10) / 10;
    const predictedStrength = Math.round(mean * 10) / 10;

    // Engineering domain ratios
    const totalBinder = Math.round((input.cement + input.slag + input.flyAsh) * 10) / 10;
    const waterToCementRatio =
      input.cement > 0 ? Math.round((input.water / input.cement) * 100) / 100 : 0;
    const waterToBinderRatio =
      totalBinder > 0 ? Math.round((input.water / totalBinder) * 100) / 100 : 0;
    const totalAggregate =
      Math.round((input.coarseAggregate + input.fineAggregate) * 10) / 10;
    const fineAggregateRatio =
      totalAggregate > 0
        ? Math.round((input.fineAggregate / totalAggregate) * 100)
        : 0;
    const estimatedDensity =
      Math.round(
        (totalBinder +
          input.water +
          input.superplasticizer +
          totalAggregate) *
          10
      ) / 10;

    // Slump / workability estimation based on engineering rules
    let slumpEstimate = 'Medium (75-100 mm)';
    if (input.superplasticizer >= 10 || waterToBinderRatio > 0.55) {
      slumpEstimate = 'High Flow / Self-Compacting (>150 mm)';
    } else if (input.superplasticizer >= 5 || waterToBinderRatio >= 0.45) {
      slumpEstimate = 'Medium-High (100-150 mm)';
    } else if (waterToBinderRatio < 0.35 && input.superplasticizer < 3) {
      slumpEstimate = 'Very Low / Stiff (<25 mm)';
    } else if (waterToBinderRatio < 0.42) {
      slumpEstimate = 'Low Workability (25-50 mm)';
    }

    // Concrete grade estimate based on 28-day equivalent or predicted value
    let grade = 'M25';
    if (predictedStrength >= 60) grade = 'M60+ High-Performance';
    else if (predictedStrength >= 50) grade = 'M50 High Strength';
    else if (predictedStrength >= 40) grade = 'M40 Structural Grade';
    else if (predictedStrength >= 30) grade = 'M30 Standard Reinforced';
    else if (predictedStrength >= 20) grade = 'M20 Plain Concrete';
    else if (predictedStrength >= 15) grade = 'M15 Lean Mix';
    else grade = 'Sub-Structural (<M15)';

    return {
      predictedStrength,
      uncertaintyStd: Math.round(uncertaintyStd * 100) / 100,
      lower95,
      upper95,
      waterToCementRatio,
      waterToBinderRatio,
      totalBinder,
      totalAggregate,
      fineAggregateRatio,
      estimatedDensity,
      slumpEstimate,
      concreteGrade: grade,
      timestamp: new Date().toISOString(),
      input: { ...input },
    };
  }
}
