export interface ConcreteSample {
  id: number;
  cement: number;             // kg/m^3
  slag: number;               // kg/m^3
  flyAsh: number;             // kg/m^3
  water: number;              // kg/m^3
  superplasticizer: number;   // kg/m^3
  coarseAggregate: number;    // kg/m^3
  fineAggregate: number;      // kg/m^3
  age: number;                // days
  strength: number;           // MPa
}

export type FeatureKey = 
  | 'cement' 
  | 'slag' 
  | 'flyAsh' 
  | 'water' 
  | 'superplasticizer' 
  | 'coarseAggregate' 
  | 'fineAggregate' 
  | 'age';

export interface FeatureMetadata {
  key: FeatureKey;
  label: string;
  shortLabel: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  defaultVal: number;
  description: string;
  engineeringRole: string;
}

export interface MixInput {
  cement: number;
  slag: number;
  flyAsh: number;
  water: number;
  superplasticizer: number;
  coarseAggregate: number;
  fineAggregate: number;
  age: number;
}

export interface PredictionResult {
  predictedStrength: number;
  uncertaintyStd: number;
  lower95: number;
  upper95: number;
  waterToCementRatio: number;
  waterToBinderRatio: number;
  totalBinder: number;
  totalAggregate: number;
  fineAggregateRatio: number;
  estimatedDensity: number;
  slumpEstimate: string;
  concreteGrade: string;
  timestamp: string;
  input: MixInput;
}

export interface ModelMetrics {
  r2: number;
  mae: number;
  rmse: number;
  trainSampleCount: number;
  testSampleCount: number;
  totalSampleCount: number;
  featureImportances: {
    key: FeatureKey;
    label: string;
    importance: number; // 0 to 1 (sums to 1)
  }[];
  testPredictions: {
    actual: number;
    predicted: number;
    residual: number;
  }[];
  trainedAt: string;
  config: {
    nTrees: number;
    maxDepth: number;
    minSamplesSplit: number;
    testSplitRatio: number;
    seed: number;
  };
}

export interface HistoryItem {
  id: string;
  name: string;
  timestamp: string;
  input: MixInput;
  result: PredictionResult;
  notes?: string;
}

export interface DatasetStatistics {
  count: number;
  min: number;
  max: number;
  mean: number;
  median: number;
  std: number;
  q1: number;
  q3: number;
}
