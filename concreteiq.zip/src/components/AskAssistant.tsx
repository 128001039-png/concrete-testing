import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Copy, Check, Trash2, ShieldCheck } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  source?: string;
  timestamp: string;
}

const SUGGESTED_CHIPS = [
  "Explain my model's RMSE",
  "Why does water content matter?",
  "What does the correlation heatmap show?",
  "How should I validate a concrete mix?",
  "What is the difference between Slag and Fly Ash?",
  "How does curing age affect compressive strength?",
];

export const AskAssistant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init',
      role: 'model',
      content: `Hello! I am **ConcreteIQ**, your AI Civil Engineering Assistant for **Experiment No. 11: Machine Learning Analytics for Concrete Compressive Strength**.

I can answer questions regarding:
- Concrete hydration chemistry and mix proportioning (IS 10262 / ACI 211)
- Supplementary cementitious materials (Slag, Fly Ash, Superplasticizers)
- Machine Learning evaluation metrics ($R^2$, MAE, RMSE, Residuals)
- Random Forest ensemble mechanics and feature importances
- Laboratory trial mix protocols and safety limits

Select a question chip below or ask any concrete analytics question!`,
      source: 'concreteiq-core',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: messages.map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!response.ok) {
        throw new Error('HTTP error ' + response.status);
      }

      const data = await response.json();
      const modelMsg: ChatMessage = {
        id: `mod_${Date.now()}`,
        role: 'model',
        content: data.reply || 'Could not process query.',
        source: data.source,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `mod_${Date.now()}`,
        role: 'model',
        content: `**ConcreteIQ Offline Knowledge Engine:**

Regarding your query: In concrete mix analytics, physical laboratory trial batches and compression machine testing (IS 516 / ASTM C39) remain the final arbiter of compressive strength. Ensure water-cementitious ratio, workability, and binder hydration comply with standard codal limits.

*(Server connection note: ${err.message || 'Offline fallback activated'})*`,
        source: 'local-fallback',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'init_reset',
        role: 'model',
        content: 'Chat cleared. Ask ConcreteIQ any questions regarding concrete mix design or machine learning metrics.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-100 font-sans">
              Ask ConcreteIQ — AI Civil Engineering Assistant
            </h2>
            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-2 py-0.5 rounded">
              Academic Lab Assistant
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono">
            Powered by Gemini AI &amp; Civil Engineering Knowledge Base · Grounded in IS 10262 &amp; Materials Analytics
          </p>
        </div>

        <button
          onClick={handleClearChat}
          className="self-start sm:self-auto px-3 py-1.5 text-xs font-mono text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded flex items-center gap-1.5 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear Conversation
        </button>
      </div>

      {/* Suggested Question Chips */}
      <div className="space-y-2">
        <span className="text-xs font-mono text-slate-400 block">Suggested Civil Engineering Topics:</span>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_CHIPS.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(chip)}
              disabled={loading}
              className="px-3 py-1.5 text-xs font-mono bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-cyan-400 border border-slate-800 hover:border-cyan-500/30 rounded-lg text-left transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
              <span>{chip}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Container */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/70 flex flex-col h-[520px] overflow-hidden shadow-xl">
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'model' && (
                <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5 shadow-sm">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-xl p-4 text-xs leading-relaxed space-y-2 ${
                  msg.role === 'user'
                    ? 'bg-cyan-500/20 text-slate-100 border border-cyan-500/40 rounded-tr-none'
                    : 'bg-slate-950/80 text-slate-200 border border-slate-800 rounded-tl-none'
                }`}
              >
                <div className="flex items-center justify-between gap-4 text-[10px] text-slate-400 pb-1 border-b border-slate-800/60 font-mono">
                  <span>{msg.role === 'user' ? 'Student' : 'ConcreteIQ Assistant'}</span>
                  <span>{msg.timestamp}</span>
                </div>

                <div className="whitespace-pre-line text-xs font-sans leading-relaxed">
                  {msg.content}
                </div>

                {msg.role === 'model' && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[10px] text-slate-500 font-mono">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      Academic Verification Protocol
                    </span>
                    <button
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="hover:text-slate-300 transition-colors flex items-center gap-1"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3.5 justify-start">
              <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl rounded-tl-none p-4 text-xs font-mono text-cyan-400 flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                <span>Formulating civil engineering response...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(input);
          }}
          className="p-3.5 border-t border-slate-800 bg-slate-950 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about RMSE, Abrams' law, hydration kinetics, or IS 10262..."
            disabled={loading}
            className="flex-1 px-4 py-2 text-xs font-mono bg-slate-900 border border-slate-800 rounded-lg text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="px-4 py-2 text-xs font-mono font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
