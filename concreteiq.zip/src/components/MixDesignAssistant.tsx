import React, { useState } from 'react';
import { MixInput } from '../types/concrete';
import { NavTab } from './Navbar';
import { Calculator, AlertTriangle, ArrowRight, BookOpen, Layers } from 'lucide-react';

interface MixDesignAssistantProps {
  onTransferToPredictor: (input: MixInput) => void;
  onNavigate: (tab: NavTab) => void;
}

export const MixDesignAssistant: React.FC<MixDesignAssistantProps> = ({
  onTransferToPredictor,
  onNavigate,
}) => {
  // Input parameters
  const [targetStrength, setTargetStrength] = useState<number>(35); // MPa
  const [cementContent, setCementContent] = useState<number>(350);  // kg/m^3
  const [coarseAgg, setCoarseAgg] = useState<number>(1020);         // kg/m^3
  const [fineAgg, setFineAgg] = useState<number>(750);              // kg/m^3
  const [slumpReq, setSlumpReq] = useState<number>(100);            // mm desired slump
  const [exposureClass, setExposureClass] = useState<'Mild' | 'Moderate' | 'Severe' | 'Very Severe'>('Moderate');

  // Engineering calculation based on IS 10262:2019 & ACI 211.1 empirical standards
  // Target Mean Strength f'_ck = f_ck + 1.65 * s (where standard deviation s ~ 4.0 - 5.0 MPa per IS 456 Table 8)
  const stdDev = targetStrength >= 40 ? 5.0 : targetStrength >= 20 ? 4.0 : 3.5;
  const targetMeanStrength = targetStrength + 1.65 * stdDev;

  // Maximum permissible w/c per IS 456 Table 5 for RCC:
  // Mild: 0.55, Moderate: 0.50, Severe: 0.45, Very Severe: 0.40
  const maxAllowableWc =
    exposureClass === 'Mild' ? 0.55 : exposureClass === 'Moderate' ? 0.50 : exposureClass === 'Severe' ? 0.45 : 0.40;

  // Minimum cement content per IS 456 Table 5:
  const minCementReq =
    exposureClass === 'Mild' ? 300 : exposureClass === 'Moderate' ? 300 : exposureClass === 'Severe' ? 320 : 340;

  // Preliminary Water Calculation heuristic (IS 10262 Table 2: 20mm aggregate baseline is ~186 kg/m³ for 50mm slump)
  // For higher slump: +3% water per 25mm slump increase beyond 50mm
  const slumpDelta = Math.max(0, slumpReq - 50);
  const unplasticizedWater = 186 * (1 + (slumpDelta / 25) * 0.03);

  // Superplasticizer dosage estimation:
  // Polycarboxylate ether typically reduces water demand by 15% - 28% at 0.6% - 1.8% by weight of cement
  let waterReductionPct = 0;
  let spDosageKg = 0;

  if (targetStrength >= 45) {
    // High strength demands low w/c (~0.32-0.38) -> requires high SP dosage (~1.5% - 2.0% of cement)
    waterReductionPct = 0.25;
    spDosageKg = Math.round(cementContent * 0.018 * 10) / 10;
  } else if (targetStrength >= 30) {
    // Medium-high strength -> ~1.0% SP of cement
    waterReductionPct = 0.18;
    spDosageKg = Math.round(cementContent * 0.012 * 10) / 10;
  } else {
    // Normal strength -> ~0.6% SP of cement
    waterReductionPct = 0.10;
    spDosageKg = Math.round(cementContent * 0.007 * 10) / 10;
  }

  const estimatedWater = Math.round(unplasticizedWater * (1 - waterReductionPct));
  const calculatedWc = cementContent > 0 ? Math.round((estimatedWater / cementContent) * 100) / 100 : 0;

  // Inconsistency checks
  const warnings: string[] = [];
  if (calculatedWc > maxAllowableWc) {
    warnings.push(`Calculated w/c (${calculatedWc}) exceeds the maximum permissible limit (${maxAllowableWc}) for ${exposureClass} exposure (IS 456 Table 5). Consider increasing cement content.`);
  }
  if (cementContent < minCementReq) {
    warnings.push(`Cement content (${cementContent} kg/m³) is below the minimum code threshold (${minCementReq} kg/m³) for ${exposureClass} durability.`);
  }
  const totalAggregate = coarseAgg + fineAgg;
  const sandFraction = totalAggregate > 0 ? (fineAgg / totalAggregate) * 100 : 0;
  if (sandFraction < 32 || sandFraction > 48) {
    warnings.push(`Sand proportion is ${sandFraction.toFixed(0)}%. Typical pumpable/workable concrete requires 34% - 44% fine aggregate fraction.`);
  }

  const handleTestInPredictor = () => {
    const mix: MixInput = {
      cement: cementContent,
      slag: 0,
      flyAsh: 0,
      water: estimatedWater,
      superplasticizer: spDosageKg,
      coarseAggregate: coarseAgg,
      fineAggregate: fineAgg,
      age: 28,
    };
    onTransferToPredictor(mix);
    onNavigate('predictor');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-100 font-sans">
          Concrete Mix Design Heuristics Assistant
        </h2>
        <p className="text-xs text-slate-400 font-mono">
          Preliminary water and superplasticizer dosage investigation governed by IS 10262:2019 and ACI 211 guidelines
        </p>
      </div>

      {/* Engineering Method Disclaimer Notice */}
      <div className="p-4 rounded-xl border border-blue-500/30 bg-blue-950/20 text-slate-300 text-xs leading-relaxed space-y-2">
        <div className="flex items-center gap-2 text-cyan-400 font-mono font-semibold">
          <BookOpen className="w-4 h-4" />
          <span>Preliminary Estimation Method & Documented Engineering Assumptions</span>
        </div>
        <p>
          This workspace implements established empirical civil engineering mix design equations from <strong>IS 10262:2019</strong> and <strong>ACI 211.1</strong>. It evaluates target mean compressive strength (f&apos;ck = fck + 1.65&sigma;), calculates unplasticized water demand for 20mm angular coarse aggregate, and determines polycarboxylate ether superplasticizer water reduction.
        </p>
        <p className="text-slate-400 text-[11px]">
          *Important: This heuristic calculation does not use the Random Forest model to directly fabricate water values; rather, it allows engineers to formulate a preliminary mix and subsequently verify it with the trained ML model.
        </p>
      </div>

      {/* Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Input Form */}
        <div className="lg:col-span-6 rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Calculator className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-100 font-sans">
              Trial Mix Input Parameters
            </h3>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <label className="text-slate-300">Target Characteristic Strength (fck):</label>
                <span className="text-cyan-400 font-bold">{targetStrength} MPa</span>
              </div>
              <input
                type="range"
                min="15"
                max="65"
                step="5"
                value={targetStrength}
                onChange={(e) => setTargetStrength(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>M15 Lean</span>
                <span>M25 Standard</span>
                <span>M40 Structural</span>
                <span>M60 High Strength</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <label className="text-slate-300">Specified Portland Cement Content:</label>
                <span className="text-cyan-400 font-bold">{cementContent} kg/m³</span>
              </div>
              <input
                type="range"
                min="240"
                max="520"
                step="10"
                value={cementContent}
                onChange={(e) => setCementContent(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <span className="text-[10px] text-slate-500 font-mono">
                Minimum {minCementReq} kg/m³ required for {exposureClass} exposure
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Coarse Aggregate (kg/m³):
                </label>
                <input
                  type="number"
                  min="800"
                  max="1200"
                  step="10"
                  value={coarseAgg}
                  onChange={(e) => setCoarseAgg(Number(e.target.value))}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Fine Aggregate (kg/m³):
                </label>
                <input
                  type="number"
                  min="550"
                  max="950"
                  step="10"
                  value={fineAgg}
                  onChange={(e) => setFineAgg(Number(e.target.value))}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Workability Slump (mm):
                </label>
                <select
                  value={slumpReq}
                  onChange={(e) => setSlumpReq(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-cyan-400"
                >
                  <option value={50}>50 mm (Low / Pavements)</option>
                  <option value={75}>75 mm (Medium / Beams & Slabs)</option>
                  <option value={100}>100 mm (High / Pumpable)</option>
                  <option value={150}>150 mm (Very High / Tremie/Piles)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  Environmental Exposure:
                </label>
                <select
                  value={exposureClass}
                  onChange={(e) => setExposureClass(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-cyan-400"
                >
                  <option value="Mild">Mild (Sheltered Interior)</option>
                  <option value="Moderate">Moderate (Normal Rain)</option>
                  <option value="Severe">Severe (Coastal / Wet-Dry)</option>
                  <option value="Very Severe">Very Severe (Aggressive Marine)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Heuristic Investigation Output */}
        <div className="lg:col-span-6 rounded-xl border border-slate-800 bg-slate-900/80 p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-300">
              HEURISTIC RECOMMENDATION (IS 10262)
            </h3>
            <span className="text-xs font-mono text-cyan-400">
              Grade M{targetStrength}
            </span>
          </div>

          {/* Key Output Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 block">EST. WATER DEMAND</span>
              <span className="text-2xl font-bold font-mono text-cyan-400">{estimatedWater}</span>
              <span className="text-xs font-mono text-slate-400 ml-1">kg/m³</span>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 block">SUPERPLASTICIZER</span>
              <span className="text-2xl font-bold font-mono text-emerald-400">{spDosageKg}</span>
              <span className="text-xs font-mono text-slate-400 ml-1">kg/m³</span>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 col-span-2 sm:col-span-1">
              <span className="text-[10px] font-mono text-slate-400 block">W/C RATIO</span>
              <span className={`text-2xl font-bold font-mono ${calculatedWc > maxAllowableWc ? 'text-rose-400' : 'text-slate-100'}`}>
                {calculatedWc}
              </span>
              <span className="text-[10px] font-mono text-slate-400 block">
                Max Code: {maxAllowableWc}
              </span>
            </div>
          </div>

          {/* Target Mean Strength info */}
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Target Mean Strength (f&apos;ck):</span>
              <strong className="text-slate-100">{targetMeanStrength.toFixed(1)} MPa</strong>
            </div>
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Formula: fck + 1.65 × s (s = {stdDev} MPa):</span>
              <span>IS 456 Table 8</span>
            </div>
            <div className="flex justify-between text-slate-300 pt-1 border-t border-slate-800">
              <span>Water reduction via PCE admixture:</span>
              <span className="text-cyan-400 font-semibold">{(waterReductionPct * 100).toFixed(0)}% reduction</span>
            </div>
          </div>

          {/* Inconsistency Warnings */}
          {warnings.length > 0 && (
            <div className="p-3.5 rounded-lg border border-amber-500/30 bg-amber-500/10 space-y-2 text-xs">
              <div className="flex items-center gap-1.5 text-amber-400 font-semibold font-mono">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Engineering Inconsistency Alerts:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                {warnings.map((w, i) => (
                  <li key={i}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Action: Transfer to Predictor */}
          <div className="pt-2 border-t border-slate-800 space-y-3">
            <button
              onClick={handleTestInPredictor}
              className="w-full py-3 px-4 text-xs font-bold font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-md shadow-cyan-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <Layers className="w-4 h-4" />
              Transfer Mix to Strength Predictor Studio
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <p className="text-[11px] text-slate-400 text-center font-mono">
              Validates proposed mix against historical UCI machine learning dataset
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
