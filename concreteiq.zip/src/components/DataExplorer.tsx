import React, { useState, useMemo } from 'react';
import { ConcreteSample, FeatureKey } from '../types/concrete';
import { FEATURE_METADATA } from '../utils/featureMetadata';
import { Download, Upload, Search, ArrowUpDown, ChevronLeft, ChevronRight, BarChart2, ScatterChart as ScatterIcon, Grid, Table as TableIcon } from 'lucide-react';

interface DataExplorerProps {
  dataset: ConcreteSample[];
  onUploadDataset?: (newSamples: ConcreteSample[]) => void;
  onResetOfficialDataset?: () => void;
}

type ExplorerTab = 'scatter' | 'histogram' | 'heatmap' | 'table' | 'statistics';

type AllColKey = FeatureKey | 'strength';

const ALL_COLS: { key: AllColKey; label: string; unit: string }[] = [
  { key: 'cement', label: 'Cement', unit: 'kg/m³' },
  { key: 'slag', label: 'Slag', unit: 'kg/m³' },
  { key: 'flyAsh', label: 'Fly Ash', unit: 'kg/m³' },
  { key: 'water', label: 'Water', unit: 'kg/m³' },
  { key: 'superplasticizer', label: 'Superplasticizer', unit: 'kg/m³' },
  { key: 'coarseAggregate', label: 'Coarse Agg.', unit: 'kg/m³' },
  { key: 'fineAggregate', label: 'Fine Agg.', unit: 'kg/m³' },
  { key: 'age', label: 'Age', unit: 'days' },
  { key: 'strength', label: 'Strength', unit: 'MPa' },
];

export const DataExplorer: React.FC<DataExplorerProps> = ({
  dataset,
  onUploadDataset,
  onResetOfficialDataset,
}) => {
  const [activeTab, setActiveTab] = useState<ExplorerTab>('scatter');

  // Scatter plot state
  const [xVar, setXVar] = useState<AllColKey>('water');
  const [yVar, setYVar] = useState<AllColKey>('strength');
  const [hoveredScatter, setHoveredScatter] = useState<ConcreteSample | null>(null);

  // Histogram state
  const [histVar, setHistVar] = useState<AllColKey>('strength');

  // Table pagination, search, sort
  const [searchQuery, setSearchQuery] = useState('');
  const [sortKey, setSortKey] = useState<AllColKey>('strength');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;

  // Correlation Matrix calculation (9x9)
  const correlationMatrix = useMemo(() => {
    const n = dataset.length;
    if (n === 0) return {};

    const means: Record<AllColKey, number> = {} as any;
    const stds: Record<AllColKey, number> = {} as any;

    for (const col of ALL_COLS) {
      let sum = 0;
      for (const row of dataset) sum += row[col.key];
      const mean = sum / n;
      means[col.key] = mean;

      let varSum = 0;
      for (const row of dataset) varSum += (row[col.key] - mean) ** 2;
      stds[col.key] = Math.sqrt(varSum / n) || 1;
    }

    const matrix: Record<string, number> = {};
    for (const c1 of ALL_COLS) {
      for (const c2 of ALL_COLS) {
        if (c1.key === c2.key) {
          matrix[`${c1.key}_${c2.key}`] = 1.0;
          continue;
        }
        let cov = 0;
        for (const row of dataset) {
          cov += (row[c1.key] - means[c1.key]) * (row[c2.key] - means[c2.key]);
        }
        const r = cov / (n * stds[c1.key] * stds[c2.key]);
        matrix[`${c1.key}_${c2.key}`] = Math.round(r * 100) / 100;
      }
    }
    return matrix;
  }, [dataset]);

  // Summary statistics calculation
  const summaryStats = useMemo(() => {
    const n = dataset.length;
    if (n === 0) return [];

    return ALL_COLS.map((col) => {
      const vals = dataset.map((d) => d[col.key]).sort((a, b) => a - b);
      const min = vals[0];
      const max = vals[vals.length - 1];
      const sum = vals.reduce((a, b) => a + b, 0);
      const mean = sum / n;
      const median = vals[Math.floor(n / 2)];
      const q1 = vals[Math.floor(n * 0.25)];
      const q3 = vals[Math.floor(n * 0.75)];

      let varSum = 0;
      for (const v of vals) varSum += (v - mean) ** 2;
      const std = Math.sqrt(varSum / n);

      return {
        key: col.key,
        label: col.label,
        unit: col.unit,
        count: n,
        min: min.toFixed(1),
        max: max.toFixed(1),
        mean: mean.toFixed(1),
        median: median.toFixed(1),
        std: std.toFixed(2),
        q1: q1.toFixed(1),
        q3: q3.toFixed(1),
      };
    });
  }, [dataset]);

  // Scatter Plot trendline and correlation
  const scatterStats = useMemo(() => {
    const n = dataset.length;
    if (n === 0) return { r: 0, minX: 0, maxX: 100, minY: 0, maxY: 100, slope: 0, intercept: 0 };

    let sumX = 0;
    let sumY = 0;
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    for (const d of dataset) {
      const x = d[xVar];
      const y = d[yVar];
      sumX += x;
      sumY += y;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }

    const meanX = sumX / n;
    const meanY = sumY / n;

    let num = 0;
    let denX = 0;
    let denY = 0;

    for (const d of dataset) {
      const dx = d[xVar] - meanX;
      const dy = d[yVar] - meanY;
      num += dx * dy;
      denX += dx * dx;
      denY += dy * dy;
    }

    const r = denX > 0 && denY > 0 ? num / Math.sqrt(denX * denY) : 0;
    const slope = denX > 0 ? num / denX : 0;
    const intercept = meanY - slope * meanX;

    return {
      r: Math.round(r * 1000) / 1000,
      minX,
      maxX,
      minY,
      maxY,
      slope,
      intercept,
    };
  }, [dataset, xVar, yVar]);

  // Histogram bins calculation
  const histData = useMemo(() => {
    const vals = dataset.map((d) => d[histVar]);
    if (vals.length === 0) return { bins: [], min: 0, max: 0, mean: 0 };

    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const sum = vals.reduce((a, b) => a + b, 0);
    const mean = sum / vals.length;

    const numBins = 16;
    const binWidth = (max - min) / numBins || 1;

    const bins = Array.from({ length: numBins }, (_, i) => {
      const bMin = min + i * binWidth;
      const bMax = bMin + binWidth;
      return {
        binMin: bMin,
        binMax: bMax,
        label: `${bMin.toFixed(0)}-${bMax.toFixed(0)}`,
        count: 0,
      };
    });

    for (const v of vals) {
      let bIdx = Math.floor((v - min) / binWidth);
      if (bIdx >= numBins) bIdx = numBins - 1;
      if (bIdx < 0) bIdx = 0;
      bins[bIdx].count++;
    }

    const maxCount = Math.max(...bins.map((b) => b.count), 1);
    return { bins, min, max, mean, maxCount };
  }, [dataset, histVar]);

  // Filtered & sorted table data
  const filteredData = useMemo(() => {
    let result = [...dataset];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (r) =>
          r.cement.toString().includes(q) ||
          r.strength.toString().includes(q) ||
          r.age.toString().includes(q) ||
          r.id.toString().includes(q)
      );
    }

    result.sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      return sortDir === 'asc' ? valA - valB : valB - valA;
    });

    return result;
  }, [dataset, searchQuery, sortKey, sortDir]);

  const totalPages = Math.ceil(filteredData.length / pageSize) || 1;
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage]);

  const handleSort = (col: AllColKey) => {
    if (sortKey === col) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(col);
      setSortDir('desc');
    }
    setCurrentPage(1);
  };

  // Export full dataset as CSV
  const handleExportCSV = () => {
    const headers = ALL_COLS.map((c) => c.key).join(',');
    const rows = dataset.map((d) =>
      ALL_COLS.map((c) => d[c.key]).join(',')
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'uci_concrete_compressive_strength.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle CSV upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onUploadDataset) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const lines = text.trim().split('\n');
      if (lines.length < 2) return;

      const parsed: ConcreteSample[] = [];
      // naive parse skipping header
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',').map((p) => parseFloat(p.trim()));
        if (parts.length >= 9 && !parts.some(isNaN)) {
          parsed.push({
            id: i,
            cement: parts[0],
            slag: parts[1],
            flyAsh: parts[2],
            water: parts[3],
            superplasticizer: parts[4],
            coarseAggregate: parts[5],
            fineAggregate: parts[6],
            age: Math.round(parts[7]),
            strength: parts[8],
          });
        }
      }

      if (parsed.length >= 20) {
        onUploadDataset(parsed);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header & Section Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 font-sans">
            Data Analytics Laboratory & Feature Explorer
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            Investigate distributions, correlations, and interactions across {dataset.length} experimental concrete batches
          </p>
        </div>

        {/* Tab switcher buttons */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 shrink-0">
          <button
            onClick={() => setActiveTab('scatter')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center gap-1.5 transition-colors ${
              activeTab === 'scatter' ? 'bg-slate-800 text-cyan-400 font-semibold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ScatterIcon className="w-3.5 h-3.5" />
            X-Y Scatter
          </button>
          <button
            onClick={() => setActiveTab('histogram')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center gap-1.5 transition-colors ${
              activeTab === 'histogram' ? 'bg-slate-800 text-cyan-400 font-semibold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            Distributions
          </button>
          <button
            onClick={() => setActiveTab('heatmap')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center gap-1.5 transition-colors ${
              activeTab === 'heatmap' ? 'bg-slate-800 text-cyan-400 font-semibold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            Correlation
          </button>
          <button
            onClick={() => setActiveTab('statistics')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center gap-1.5 transition-colors ${
              activeTab === 'statistics' ? 'bg-slate-800 text-cyan-400 font-semibold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Summary Stats
          </button>
          <button
            onClick={() => setActiveTab('table')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center gap-1.5 transition-colors ${
              activeTab === 'table' ? 'bg-slate-800 text-cyan-400 font-semibold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5" />
            Data Table
          </button>
        </div>
      </div>

      {/* TAB 1: X-Y SCATTER PLOT */}
      {activeTab === 'scatter' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl border border-slate-800 bg-slate-900/60">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400">X-Axis Variable:</span>
                <select
                  value={xVar}
                  onChange={(e) => setXVar(e.target.value as AllColKey)}
                  className="px-2.5 py-1 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-cyan-400"
                >
                  {ALL_COLS.map((c) => (
                    <option key={c.key} value={c.key}>
                      {c.label} ({c.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400">Y-Axis Variable:</span>
                <select
                  value={yVar}
                  onChange={(e) => setYVar(e.target.value as AllColKey)}
                  className="px-2.5 py-1 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-cyan-400"
                >
                  {ALL_COLS.map((c) => (
                    <option key={c.key} value={c.key}>
                      {c.label} ({c.unit})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="text-slate-400">Pearson Correlation (r):</span>
              <span className={`font-bold px-2 py-0.5 rounded border ${
                Math.abs(scatterStats.r) >= 0.4
                  ? 'text-cyan-400 border-cyan-500/30 bg-cyan-950/40'
                  : 'text-slate-300 border-slate-700 bg-slate-800/40'
              }`}>
                {scatterStats.r > 0 ? `+${scatterStats.r}` : scatterStats.r}
              </span>
            </div>
          </div>

          {/* SVG Canvas for Scatter Plot */}
          <div className="relative w-full h-[420px] rounded-xl border border-slate-800 bg-slate-950/90 p-4 overflow-hidden">
            <svg viewBox="0 0 700 380" className="w-full h-full">
              {/* Axes and Grid Lines */}
              {[0.2, 0.4, 0.6, 0.8, 1.0].map((frac, idx) => {
                const yPos = 340 - frac * 300;
                const xPos = 60 + frac * 600;
                return (
                  <g key={idx} className="text-slate-800/80">
                    <line x1="60" y1={yPos} x2="660" y2={yPos} stroke="currentColor" strokeDasharray="3 3" />
                    <line x1={xPos} y1="40" x2={xPos} y2="340" stroke="currentColor" strokeDasharray="3 3" />
                  </g>
                );
              })}

              {/* Linear Regression Trendline */}
              {(() => {
                const xRange = scatterStats.maxX - scatterStats.minX || 1;
                const yRange = scatterStats.maxY - scatterStats.minY || 1;
                const x1 = scatterStats.minX;
                const y1 = scatterStats.slope * x1 + scatterStats.intercept;
                const x2 = scatterStats.maxX;
                const y2 = scatterStats.slope * x2 + scatterStats.intercept;

                const sx1 = 60;
                const sy1 = 340 - ((y1 - scatterStats.minY) / yRange) * 300;
                const sx2 = 660;
                const sy2 = 340 - ((y2 - scatterStats.minY) / yRange) * 300;

                return (
                  <line
                    x1={sx1}
                    y1={Math.max(40, Math.min(340, sy1))}
                    x2={sx2}
                    y2={Math.max(40, Math.min(340, sy2))}
                    stroke="#10B981"
                    strokeWidth="2"
                    strokeDasharray="4 4"
                    opacity="0.8"
                  />
                );
              })()}

              {/* Data Points */}
              {dataset.map((pt, i) => {
                const xRange = scatterStats.maxX - scatterStats.minX || 1;
                const yRange = scatterStats.maxY - scatterStats.minY || 1;
                const cx = 60 + ((pt[xVar] - scatterStats.minX) / xRange) * 600;
                const cy = 340 - ((pt[yVar] - scatterStats.minY) / yRange) * 300;
                const isHovered = hoveredScatter === pt;

                return (
                  <circle
                    key={pt.id || i}
                    cx={cx}
                    cy={cy}
                    r={isHovered ? 6 : 3}
                    fill={isHovered ? '#F59E0B' : '#06B6D4'}
                    fillOpacity={isHovered ? 1 : 0.6}
                    stroke="#0F172A"
                    strokeWidth={0.75}
                    className="cursor-pointer transition-all hover:scale-150"
                    onMouseEnter={() => setHoveredScatter(pt)}
                  />
                );
              })}

              {/* Outer Axis Borders */}
              <line x1="60" y1="340" x2="660" y2="340" stroke="#475569" strokeWidth="1.5" />
              <line x1="60" y1="40" x2="60" y2="340" stroke="#475569" strokeWidth="1.5" />

              {/* Axis Min/Max Ticks */}
              <text x="60" y="358" textAnchor="middle" fontSize="10" className="fill-slate-400 font-mono">
                {scatterStats.minX.toFixed(1)}
              </text>
              <text x="660" y="358" textAnchor="middle" fontSize="10" className="fill-slate-400 font-mono">
                {scatterStats.maxX.toFixed(1)}
              </text>
              <text x="50" y="344" textAnchor="end" fontSize="10" className="fill-slate-400 font-mono">
                {scatterStats.minY.toFixed(1)}
              </text>
              <text x="50" y="44" textAnchor="end" fontSize="10" className="fill-slate-400 font-mono">
                {scatterStats.maxY.toFixed(1)}
              </text>

              {/* Axis Titles */}
              <text x="360" y="375" textAnchor="middle" fontSize="11" className="fill-slate-300 font-mono font-medium">
                {ALL_COLS.find((c) => c.key === xVar)?.label} ({ALL_COLS.find((c) => c.key === xVar)?.unit})
              </text>
              <text x="18" y="190" textAnchor="middle" transform="rotate(-90 18 190)" fontSize="11" className="fill-slate-300 font-mono font-medium">
                {ALL_COLS.find((c) => c.key === yVar)?.label} ({ALL_COLS.find((c) => c.key === yVar)?.unit})
              </text>
            </svg>

            {/* Hover details HUD */}
            {hoveredScatter && (
              <div className="absolute top-4 right-4 bg-slate-900/95 border border-cyan-500/40 rounded-lg p-3 text-xs font-mono shadow-2xl space-y-1">
                <div className="text-[10px] text-cyan-400 uppercase font-semibold">Specimen #{hoveredScatter.id}</div>
                <div>{ALL_COLS.find((c) => c.key === xVar)?.label}: <strong>{hoveredScatter[xVar]} {ALL_COLS.find((c) => c.key === xVar)?.unit}</strong></div>
                <div>{ALL_COLS.find((c) => c.key === yVar)?.label}: <strong>{hoveredScatter[yVar]} {ALL_COLS.find((c) => c.key === yVar)?.unit}</strong></div>
                <div>Age: <strong>{hoveredScatter.age} Days</strong></div>
                <div>Strength: <strong className="text-emerald-400">{hoveredScatter.strength} MPa</strong></div>
              </div>
            )}
          </div>

          {/* Civil Engineering Interpretation Box */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 text-xs text-slate-300 leading-relaxed space-y-1">
            <strong className="text-cyan-400 font-mono block">CIVIL ENGINEERING INTERPRETATION:</strong>
            {xVar === 'water' && yVar === 'strength' && (
              <span>Negative slope verifies Abrams&apos; law: increasing water reduces the gel-space ratio of the C-S-H matrix, increasing capillary porosity and reducing compressive resistance.</span>
            )}
            {xVar === 'cement' && yVar === 'strength' && (
              <span>Strong positive correlation: increasing Portland cement elevates calcium silicate hydrate (C-S-H) solid volume, directly driving load-bearing capability.</span>
            )}
            {xVar === 'age' && yVar === 'strength' && (
              <span>Logarithmic growth curve: hydration proceeds rapidly in the first 28 days and levels off thereafter as capillary paths densify.</span>
            )}
            {xVar !== 'water' && xVar !== 'cement' && xVar !== 'age' && (
              <span>Scatter distribution illustrates multi-component material interactions. Single-variable lines show scatter because strength is simultaneously influenced by the full 8-component mix proportions.</span>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: HISTOGRAM DISTRIBUTIONS */}
      {activeTab === 'histogram' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-xl border border-slate-800 bg-slate-900/60">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-slate-400">Select Variable:</span>
              <select
                value={histVar}
                onChange={(e) => setHistVar(e.target.value as AllColKey)}
                className="px-2.5 py-1 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-cyan-400"
              >
                {ALL_COLS.map((c) => (
                  <option key={c.key} value={c.key}>
                    {c.label} ({c.unit})
                  </option>
                ))}
              </select>
            </div>
            <div className="text-xs font-mono text-slate-400">
              Mean: <strong className="text-cyan-400">{histData.mean.toFixed(1)}</strong> · Range: {histData.min.toFixed(1)} to {histData.max.toFixed(1)}
            </div>
          </div>

          <div className="p-6 rounded-xl border border-slate-800 bg-slate-950/90 space-y-4">
            <div className="h-64 flex items-end gap-1.5 sm:gap-2 pt-6 px-4">
              {histData.bins.map((bin, idx) => {
                const maxCount = histData.maxCount || 1;
                const heightPct = Math.round((bin.count / maxCount) * 100);
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                    <div
                      className="w-full bg-cyan-500/70 hover:bg-cyan-400 rounded-t transition-all group-hover:scale-y-105 origin-bottom"
                      style={{ height: `${Math.max(4, heightPct)}%` }}
                    />
                    <span className="text-[9px] font-mono text-slate-500 truncate max-w-full">
                      {bin.binMin.toFixed(0)}
                    </span>

                    {/* Tooltip on bar hover */}
                    <div className="absolute -top-10 bg-slate-900 border border-cyan-500/40 text-slate-200 text-[10px] font-mono px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-20">
                      {bin.label}: <strong>{bin.count} batches</strong>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="text-center text-xs font-mono text-slate-400">
              {ALL_COLS.find((c) => c.key === histVar)?.label} Interval ({ALL_COLS.find((c) => c.key === histVar)?.unit})
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: 9x9 CORRELATION HEATMAP */}
      {activeTab === 'heatmap' && (
        <div className="space-y-4">
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/70 overflow-x-auto">
            <div className="min-w-[620px]">
              <div className="grid grid-cols-10 gap-1 text-[11px] font-mono text-center mb-1">
                <div />
                {ALL_COLS.map((c) => (
                  <div key={c.key} className="text-slate-400 font-semibold truncate p-1">
                    {c.key === 'superplasticizer' ? 'SP' : c.label}
                  </div>
                ))}
              </div>

              {ALL_COLS.map((rowCol) => (
                <div key={rowCol.key} className="grid grid-cols-10 gap-1 text-[11px] font-mono text-center items-center my-1">
                  <div className="text-right pr-2 text-slate-400 font-semibold truncate">
                    {rowCol.key === 'superplasticizer' ? 'SP' : rowCol.label}
                  </div>
                  {ALL_COLS.map((colCol) => {
                    const r = correlationMatrix[`${rowCol.key}_${colCol.key}`] ?? 0;
                    const isDiag = rowCol.key === colCol.key;

                    let bg = 'bg-slate-800/40';
                    let text = 'text-slate-400';
                    if (isDiag) {
                      bg = 'bg-cyan-500/20';
                      text = 'text-cyan-300 font-bold';
                    } else if (r >= 0.4) {
                      bg = 'bg-emerald-500/40';
                      text = 'text-emerald-200 font-bold';
                    } else if (r >= 0.15) {
                      bg = 'bg-emerald-500/20';
                      text = 'text-emerald-300';
                    } else if (r <= -0.4) {
                      bg = 'bg-rose-500/40';
                      text = 'text-rose-200 font-bold';
                    } else if (r <= -0.15) {
                      bg = 'bg-amber-500/20';
                      text = 'text-amber-300';
                    }

                    return (
                      <div
                        key={colCol.key}
                        className={`h-9 flex items-center justify-center rounded border border-slate-800/80 ${bg} ${text} transition-transform hover:scale-110 cursor-default`}
                        title={`${rowCol.label} vs ${colCol.label}: r = ${r}`}
                      >
                        {r.toFixed(2)}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center justify-between text-xs font-mono text-slate-400 pt-4 border-t border-slate-800">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-emerald-500/40" /> Positive Correlation (&ge; +0.40)</span>
                <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-rose-500/40" /> Negative Correlation (&le; -0.40)</span>
              </div>
              <span>Values indicate Pearson r (-1.0 to +1.0)</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SUMMARY STATISTICS */}
      {activeTab === 'statistics' && (
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Feature</th>
                  <th className="py-3 px-3">Unit</th>
                  <th className="py-3 px-3 text-right">Count</th>
                  <th className="py-3 px-3 text-right">Mean</th>
                  <th className="py-3 px-3 text-right">Std Dev</th>
                  <th className="py-3 px-3 text-right">Min</th>
                  <th className="py-3 px-3 text-right">Q1 (25%)</th>
                  <th className="py-3 px-3 text-right">Median</th>
                  <th className="py-3 px-3 text-right">Q3 (75%)</th>
                  <th className="py-3 px-3 text-right">Max</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {summaryStats.map((row) => (
                  <tr key={row.key} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-4 font-semibold text-slate-200">{row.label}</td>
                    <td className="py-2.5 px-3 text-slate-400">{row.unit}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{row.count}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-cyan-400">{row.mean}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{row.std}</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{row.min}</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{row.q1}</td>
                    <td className="py-2.5 px-3 text-right text-slate-200 font-medium">{row.median}</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{row.q3}</td>
                    <td className="py-2.5 px-3 text-right text-slate-100 font-bold">{row.max}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: DATA TABLE (SEARCHABLE, SORTABLE, PAGINATED) */}
      {activeTab === 'table' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border border-slate-800 bg-slate-900/60">
            {/* Search Input */}
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search by cement, age, strength..."
                className="w-full pl-9 pr-3 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-slate-100 placeholder:text-slate-500"
              />
            </div>

            {/* Actions: Download CSV, Upload CSV */}
            <div className="flex items-center gap-2">
              <label className="px-3 py-1.5 text-xs font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 flex items-center gap-1.5 cursor-pointer transition-colors">
                <Upload className="w-3.5 h-3.5 text-cyan-400" />
                Upload CSV
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              <button
                onClick={handleExportCSV}
                className="px-3 py-1.5 text-xs font-mono font-medium text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Download CSV
              </button>

              {onResetOfficialDataset && dataset.length !== 1030 && (
                <button
                  onClick={onResetOfficialDataset}
                  className="px-3 py-1.5 text-xs font-mono text-amber-400 hover:text-amber-300 bg-amber-950/40 border border-amber-500/30 rounded"
                >
                  Reset Official UCI
                </button>
              )}
            </div>
          </div>

          {/* Table Container */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 select-none">
                  <tr>
                    <th className="py-2.5 px-3">#</th>
                    {ALL_COLS.map((col) => (
                      <th
                        key={col.key}
                        onClick={() => handleSort(col.key)}
                        className="py-2.5 px-3 cursor-pointer hover:text-cyan-400 transition-colors"
                      >
                        <div className="flex items-center gap-1">
                          <span>{col.label}</span>
                          <ArrowUpDown className="w-3 h-3 opacity-60" />
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {paginatedData.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2 px-3 text-slate-500">{row.id}</td>
                      <td className="py-2 px-3 text-slate-300">{row.cement}</td>
                      <td className="py-2 px-3 text-slate-400">{row.slag}</td>
                      <td className="py-2 px-3 text-slate-400">{row.flyAsh}</td>
                      <td className="py-2 px-3 text-slate-300">{row.water}</td>
                      <td className="py-2 px-3 text-slate-400">{row.superplasticizer}</td>
                      <td className="py-2 px-3 text-slate-300">{row.coarseAggregate}</td>
                      <td className="py-2 px-3 text-slate-300">{row.fineAggregate}</td>
                      <td className="py-2 px-3 text-cyan-400 font-bold">{row.age}d</td>
                      <td className="py-2 px-3 text-emerald-400 font-bold">{row.strength.toFixed(2)} MPa</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            <div className="p-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
              <div>
                Showing {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, filteredData.length)} of {filteredData.length} records
              </div>
              <div className="flex items-center gap-2">
                <button
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage((p) => p - 1)}
                  className="p-1 rounded bg-slate-950 border border-slate-800 disabled:opacity-40"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span>
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((p) => p + 1)}
                  className="p-1 rounded bg-slate-950 border border-slate-800 disabled:opacity-40"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
