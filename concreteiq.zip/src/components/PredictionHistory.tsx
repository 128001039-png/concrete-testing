import React, { useState } from 'react';
import { HistoryItem } from '../types/concrete';
import { NavTab } from './Navbar';
import { Trash2, Download, GitCompare, ArrowRight, ArrowUpDown, Database } from 'lucide-react';

interface PredictionHistoryProps {
  history: HistoryItem[];
  onDelete: (id: string) => void;
  onClearAll: () => void;
  onNavigate: (tab: NavTab) => void;
}

export const PredictionHistory: React.FC<PredictionHistoryProps> = ({
  history,
  onDelete,
  onClearAll,
  onNavigate,
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [sortKey, setSortKey] = useState<'timestamp' | 'strength' | 'cement'>('timestamp');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [showCompareModal, setShowCompareModal] = useState(false);

  // Sorting
  const sortedHistory = [...history].sort((a, b) => {
    let diff = 0;
    if (sortKey === 'timestamp') {
      diff = new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    } else if (sortKey === 'strength') {
      diff = a.result.predictedStrength - b.result.predictedStrength;
    } else if (sortKey === 'cement') {
      diff = a.input.cement - b.input.cement;
    }
    return sortDir === 'asc' ? diff : -diff;
  });

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      if (selectedIds.length >= 4) {
        alert('You can select a maximum of 4 mixes to compare side by side.');
        return;
      }
      setSelectedIds([...selectedIds, id]);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    if (history.length === 0) return;

    const headers = [
      'Name',
      'Timestamp',
      'PredictedStrength_MPa',
      'Grade',
      'Cement_kg_m3',
      'Slag_kg_m3',
      'FlyAsh_kg_m3',
      'Water_kg_m3',
      'Superplasticizer_kg_m3',
      'CoarseAgg_kg_m3',
      'FineAgg_kg_m3',
      'Age_days',
      'W_B_Ratio',
    ].join(',');

    const rows = history.map((h) =>
      [
        `"${h.name}"`,
        h.timestamp,
        h.result.predictedStrength,
        `"${h.result.concreteGrade}"`,
        h.input.cement,
        h.input.slag,
        h.input.flyAsh,
        h.input.water,
        h.input.superplasticizer,
        h.input.coarseAggregate,
        h.input.fineAggregate,
        h.input.age,
        h.result.waterToBinderRatio,
      ].join(',')
    );

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'concreteiq_prediction_history.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const selectedMixes = history.filter((h) => selectedIds.includes(h.id));

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 font-sans">
            Prediction History &amp; Mix Comparison
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            {history.length} saved trial evaluations · Persisted locally in browser storage
          </p>
        </div>

        <div className="flex items-center gap-2">
          {selectedIds.length >= 2 && (
            <button
              onClick={() => setShowCompareModal(true)}
              className="px-3 py-1.5 text-xs font-mono font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <GitCompare className="w-3.5 h-3.5" />
              Compare ({selectedIds.length})
            </button>
          )}

          {history.length > 0 && (
            <>
              <button
                onClick={handleExportCSV}
                className="px-3 py-1.5 text-xs font-mono text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                Export CSV
              </button>

              <button
                onClick={onClearAll}
                className="px-3 py-1.5 text-xs font-mono text-rose-400 hover:text-rose-300 bg-rose-950/30 border border-rose-500/30 rounded flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear All
              </button>
            </>
          )}
        </div>
      </div>

      {/* Storage & Persistence Notice */}
      <div className="flex items-center gap-2 text-xs font-mono text-slate-400 p-3 rounded-lg bg-slate-900/60 border border-slate-800">
        <Database className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>
          <strong>Storage Architecture:</strong> Prediction history is stored securely in your browser&apos;s <code>localStorage</code> cache. Records remain available between page refreshes and lab sessions on this computer.
        </span>
      </div>

      {/* History Items List / Table */}
      {history.length > 0 ? (
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 select-none">
                <tr>
                  <th className="py-2.5 px-3 w-10 text-center">Select</th>
                  <th className="py-2.5 px-4">Mix Name / ID</th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-cyan-400"
                    onClick={() => {
                      setSortKey('strength');
                      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
                    }}
                  >
                    <div className="flex items-center gap-1">
                      <span>Predicted Strength</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3">Grade</th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-cyan-400"
                    onClick={() => {
                      setSortKey('cement');
                      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
                    }}
                  >
                    <div className="flex items-center gap-1">
                      <span>Cement</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3">Water</th>
                  <th className="py-2.5 px-3">W/B Ratio</th>
                  <th className="py-2.5 px-3">Age</th>
                  <th
                    className="py-2.5 px-3 cursor-pointer hover:text-cyan-400"
                    onClick={() => {
                      setSortKey('timestamp');
                      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
                    }}
                  >
                    <div className="flex items-center gap-1">
                      <span>Timestamp</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {sortedHistory.map((item) => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isSelected ? 'bg-cyan-950/20' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelect(item.id)}
                          className="accent-cyan-400 cursor-pointer"
                        />
                      </td>
                      <td className="py-2.5 px-4 font-semibold text-slate-200">
                        {item.name}
                        {item.notes && (
                          <span className="block text-[10px] text-slate-400 font-normal">
                            {item.notes}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="font-bold text-cyan-400 text-sm">
                          {item.result.predictedStrength.toFixed(1)}
                        </span>{' '}
                        <span className="text-[10px] text-slate-400">MPa</span>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          {item.result.concreteGrade}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">{item.input.cement} kg/m³</td>
                      <td className="py-2.5 px-3 text-slate-300">{item.input.water} kg/m³</td>
                      <td className="py-2.5 px-3 font-semibold text-emerald-400">
                        {item.result.waterToBinderRatio}
                      </td>
                      <td className="py-2.5 px-3 text-cyan-400 font-bold">{item.input.age}d</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                        {new Date(item.timestamp).toLocaleString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => onDelete(item.id)}
                          className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                          title="Delete entry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="py-16 text-center rounded-xl border border-dashed border-slate-800 bg-slate-900/40 p-6 space-y-3">
          <p className="text-sm font-mono text-slate-400">
            No prediction records saved yet.
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Run custom mix evaluations in the Strength Predictor Studio and click &ldquo;Save to History&rdquo; to build your lab log.
          </p>
          <button
            onClick={() => onNavigate('predictor')}
            className="px-4 py-2 text-xs font-mono font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded inline-flex items-center gap-1.5 transition-colors"
          >
            Go to Predictor Studio
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Side-by-Side Comparison Modal */}
      {showCompareModal && selectedMixes.length >= 2 && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold font-sans text-slate-100">
                  Side-by-Side Concrete Mix Comparison
                </h3>
                <p className="text-xs font-mono text-slate-400">
                  Comparing {selectedMixes.length} laboratory mixes
                </p>
              </div>
              <button
                onClick={() => setShowCompareModal(false)}
                className="text-slate-400 hover:text-slate-200 font-mono text-sm"
              >
                ✕ Close
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead className="bg-slate-950 text-slate-400">
                  <tr>
                    <th className="p-3">Parameter</th>
                    {selectedMixes.map((m) => (
                      <th key={m.id} className="p-3 text-cyan-400 font-bold">
                        {m.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  <tr className="bg-cyan-950/30">
                    <td className="p-3 font-bold text-slate-200">Predicted Strength</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-emerald-400 font-bold text-base">
                        {m.result.predictedStrength.toFixed(1)} MPa
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">95% Interval</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.result.lower95} - {m.result.upper95} MPa
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Concrete Grade</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.result.concreteGrade}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Portland Cement</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.cement} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Blast Furnace Slag</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.slag} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Fly Ash</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.flyAsh} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Mixing Water</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.water} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Superplasticizer</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.superplasticizer} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Coarse Aggregate</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.coarseAggregate} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Fine Aggregate (Sand)</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-300">
                        {m.input.fineAggregate} kg/m³
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 text-slate-400">Curing Age</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-cyan-400 font-bold">
                        {m.input.age} Days
                      </td>
                    ))}
                  </tr>
                  <tr className="bg-slate-950/60 font-semibold">
                    <td className="p-3 text-slate-300">Water-to-Binder Ratio (w/b)</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-cyan-300">
                        {m.result.waterToBinderRatio}
                      </td>
                    ))}
                  </tr>
                  <tr className="bg-slate-950/60 font-semibold">
                    <td className="p-3 text-slate-300">Total Binder Content</td>
                    {selectedMixes.map((m) => (
                      <td key={m.id} className="p-3 text-slate-100">
                        {m.result.totalBinder} kg/m³
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowCompareModal(false)}
                className="px-4 py-2 text-xs font-mono font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded"
              >
                Close Comparison
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
