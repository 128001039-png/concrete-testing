import React from 'react';
import { Sun, Moon, Layers } from 'lucide-react';

export type NavTab = 
  | 'overview' 
  | 'predictor' 
  | 'explorer' 
  | 'mix-design' 
  | 'assistant' 
  | 'history' 
  | 'about';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isDark: boolean;
  toggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isDark,
  toggleTheme,
}) => {
  const navItems: { id: NavTab; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'predictor', label: 'Strength Predictor' },
    { id: 'explorer', label: 'Data Explorer' },
    { id: 'mix-design', label: 'Mix Design' },
    { id: 'assistant', label: 'Ask ConcreteIQ' },
    { id: 'history', label: 'History' },
    { id: 'about', label: 'About Project' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Brand Wordmark (Single text element with geometric specimen mark) */}
        <button
          onClick={() => setActiveTab('overview')}
          className="flex items-center gap-2.5 text-left group shrink-0"
        >
          <div className="w-8 h-8 rounded bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-sm shadow-cyan-500/20 group-hover:scale-105 transition-transform">
            <Layers className="w-4 h-4 text-slate-950" />
          </div>
          <div className="flex flex-col">
            <span className="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap font-mono">
              CONCRETE<span className="text-cyan-400">IQ</span>
            </span>
            <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wider -mt-0.5">
              Civil Analytics Lab
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (Clean single-line text links with active indicator) */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors ${
                  isActive
                    ? 'text-cyan-400 bg-slate-900 border border-cyan-500/30'
                    : 'text-slate-300 hover:text-slate-100 hover:bg-slate-900/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & Theme toggle */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-300 hover:text-slate-100 hover:bg-slate-900 rounded-lg border border-slate-800 transition-colors"
            title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-cyan-400" />}
          </button>

          <button
            onClick={() => setActiveTab('predictor')}
            className="hidden sm:inline-flex items-center px-3.5 py-1.5 text-xs font-semibold font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm shadow-cyan-500/20 transition-colors whitespace-nowrap shrink-0"
          >
            Predict Strength
          </button>
        </div>
      </div>

      {/* Mobile Tab Scrollbar */}
      <div className="lg:hidden flex items-center overflow-x-auto px-4 py-2 border-t border-slate-800/80 gap-1.5 scrollbar-none">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-2.5 py-1 text-xs font-medium rounded whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'text-cyan-400 bg-slate-900 border border-cyan-500/30 font-semibold'
                  : 'text-slate-300 hover:text-slate-100'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
