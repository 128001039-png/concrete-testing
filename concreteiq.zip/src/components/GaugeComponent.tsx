import React from 'react';

interface GaugeProps {
  value: number; // in MPa
  min?: number;
  max?: number;
  label?: string;
  subLabel?: string;
  uncertainty?: number;
  grade?: string;
  isIllustrative?: boolean;
}

export const GaugeComponent: React.FC<GaugeProps> = ({
  value,
  min = 0,
  max = 90,
  label = 'COMPRESSIVE STRENGTH',
  subLabel = '28-Day Equivalent',
  uncertainty,
  grade,
  isIllustrative = false,
}) => {
  const clampedVal = Math.min(Math.max(value, min), max);
  const percentage = (clampedVal - min) / (max - min);

  // Semi-circle SVG coordinates (from 180 to 0 degrees / Math.PI to 0)
  const radius = 105;
  const cx = 130;
  const cy = 120;
  const strokeWidth = 14;

  const startAngle = Math.PI;
  const endAngle = 0;
  const currentAngle = startAngle - percentage * Math.PI;

  // Background arc path (180 deg to 0 deg)
  const bgPath = `M ${cx - radius} ${cy} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy}`;

  // Value arc path
  const targetX = cx + radius * Math.cos(currentAngle);
  const targetY = cy - radius * Math.sin(currentAngle);
  const largeArcFlag = percentage > 0.5 ? 1 : 0;
  const valuePath = `M ${cx - radius} ${cy} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${targetX} ${targetY}`;

  // Color mapping based on MPa strength grade
  let accentColor = '#06B6D4'; // cyan
  let gradeBadgeColor = 'text-cyan-400 border-cyan-500/30 bg-cyan-950/30';
  if (value >= 50) {
    accentColor = '#10B981'; // emerald / high performance
    gradeBadgeColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-950/30';
  } else if (value >= 30) {
    accentColor = '#06B6D4'; // cyan / structural
    gradeBadgeColor = 'text-cyan-400 border-cyan-500/30 bg-cyan-950/30';
  } else if (value >= 20) {
    accentColor = '#3B82F6'; // blue / standard
    gradeBadgeColor = 'text-blue-400 border-blue-500/30 bg-blue-950/30';
  } else {
    accentColor = '#F59E0B'; // amber / lean
    gradeBadgeColor = 'text-amber-400 border-amber-500/30 bg-amber-950/30';
  }

  // Generate tick marks
  const ticks = [0, 15, 30, 45, 60, 75, 90];

  return (
    <div className="flex flex-col items-center select-none">
      <div className="relative w-[260px] h-[155px]">
        <svg viewBox="0 0 260 145" className="w-full h-full overflow-visible">
          <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3B82F6" />
              <stop offset="45%" stopColor="#06B6D4" />
              <stop offset="85%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#84CC16" />
            </linearGradient>
            <filter id="gaugeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor={accentColor} floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Background Track */}
          <path
            d={bgPath}
            fill="none"
            stroke="currentColor"
            strokeWidth={strokeWidth}
            className="text-slate-800 dark:text-slate-800/80"
            strokeLinecap="round"
          />

          {/* Progress Arc */}
          <path
            d={valuePath}
            fill="none"
            stroke="url(#gaugeGradient)"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            filter="url(#gaugeGlow)"
            className="transition-all duration-700 ease-out"
          />

          {/* Tick marks and numbers */}
          {ticks.map((t) => {
            const tickAngle = Math.PI - (t / max) * Math.PI;
            const rInner = radius - 16;
            const rOuter = radius - 8;
            const x1 = cx + rInner * Math.cos(tickAngle);
            const y1 = cy - rInner * Math.sin(tickAngle);
            const x2 = cx + rOuter * Math.cos(tickAngle);
            const y2 = cy - rOuter * Math.sin(tickAngle);
            const textR = radius - 26;
            const tx = cx + textR * Math.cos(tickAngle);
            const ty = cy - textR * Math.sin(tickAngle);

            return (
              <g key={t} className="opacity-60 text-slate-400">
                <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="currentColor" strokeWidth="1.5" />
                <text
                  x={tx}
                  y={ty}
                  textAnchor="middle"
                  dominantBaseline="central"
                  fontSize="8"
                  className="fill-slate-400 font-mono"
                >
                  {t}
                </text>
              </g>
            );
          })}

          {/* Needle pivot and pointer */}
          <circle cx={cx} cy={cy} r="6" fill="#0F172A" stroke={accentColor} strokeWidth="3" />
          <line
            x1={cx}
            y1={cy}
            x2={targetX}
            y2={targetY}
            stroke={accentColor}
            strokeWidth="2.5"
            strokeLinecap="round"
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Numeric Readout in center of arc */}
        <div className="absolute inset-x-0 bottom-0 flex flex-col items-center justify-end">
          {isIllustrative && (
            <span className="text-[10px] uppercase font-mono tracking-wider text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 mb-1">
              Illustrative Benchmark
            </span>
          )}
          <div className="flex items-baseline gap-1">
            <span className="text-4xl font-bold font-mono tracking-tight text-slate-100 tabular-nums">
              {value.toFixed(1)}
            </span>
            <span className="text-sm font-semibold font-mono text-cyan-400">MPa</span>
          </div>
        </div>
      </div>

      {/* Uncertainty & Grade tags */}
      <div className="mt-3 flex flex-col items-center gap-1.5 text-center">
        <div className="flex items-center gap-2">
          {grade && (
            <span className={`text-xs font-mono font-medium px-2 py-0.5 rounded border ${gradeBadgeColor}`}>
              Grade: {grade}
            </span>
          )}
          {uncertainty !== undefined && (
            <span className="text-xs font-mono text-slate-400 bg-slate-800/60 px-2 py-0.5 rounded border border-slate-700/50">
              ±{uncertainty.toFixed(1)} MPa (95% CI)
            </span>
          )}
        </div>
        <div className="text-xs text-slate-400 font-medium">
          {label} <span className="opacity-50">·</span> {subLabel}
        </div>
      </div>
    </div>
  );
};
