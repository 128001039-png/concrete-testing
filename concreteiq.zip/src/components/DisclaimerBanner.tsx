import React, { useState } from 'react';
import { ShieldAlert, ChevronDown, ChevronUp } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="border-b border-amber-500/20 bg-amber-500/5 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
            <div className="text-xs leading-relaxed">
              <span className="font-semibold text-amber-300 mr-1.5 uppercase tracking-wider font-mono">
                Engineering Safety Notice:
              </span>
              {!collapsed ? (
                <span>
                  ConcreteIQ provides educational predictions based on historical data. Model predictions are not guarantees of actual concrete performance and do not constitute an approved structural mix design. Any proposed mix must be designed and verified using applicable standards, laboratory trial mixes, material testing, and qualified engineering judgement before practical implementation.
                </span>
              ) : (
                <span className="text-slate-400">
                  Model predictions are educational estimations and require physical laboratory validation per IS/ACI standards...
                </span>
              )}
            </div>
          </div>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-slate-400 hover:text-slate-200 text-xs shrink-0 flex items-center gap-1 transition-colors"
            title={collapsed ? 'Expand disclaimer' : 'Collapse disclaimer'}
          >
            {collapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
