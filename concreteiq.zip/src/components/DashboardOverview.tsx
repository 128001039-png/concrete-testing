import React, { useState } from 'react';
import { ModelMetrics, PredictionResult } from '../types/concrete';
import { NavTab } from './Navbar';
import { RefreshCw, Sliders, CheckCircle, HelpCircle, ArrowRight } from 'lucide-react';

interface DashboardOverviewProps {
  metrics: ModelMetrics;
  onRetrain: (config: { nTrees: number; maxDepth: number; testSplitRatio: number; seed: number }) => void;
  isTraining: boolean;
  latestPrediction: PredictionResult | null;
  onNavigate: (tab: NavTab) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  metrics,
  onRetrain,
  isTraining,
  latestPrediction,
  onNavigate,
}) => {
  const [showConfig, setShowConfig] = useState(false);
  const [nTrees, setNTrees] = useState(metrics.config.nTrees);
  const [maxDepth, setMaxDepth] = useState(metrics.config.maxDepth);
  const [testSplit, setTestSplit] = useState(metrics.config.testSplitRatio);
  const [seed, setSeed] = useState(metrics.config.seed);
  const [activePlotTab, setActivePlotTab] = useState<'scatter' | 'residuals'>('scatter');
  const [selectedPoint, setSelectedPoint] = useState<{ actual: number; predicted: number; residual: number } | null>(null);

  const handleRetrainSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRetrain({
      nTrees,
      maxDepth,
      testSplitRatio: testSplit,
      seed,
    });
  };

  return (
    <div className="space-y-8">
      {/* Top Telemetry & Status Ribbon */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl border border-slate-800 bg-slate-900/60 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-100 font-mono">
                Random Forest Regressor
              </span>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded">
                Trained & Validated
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              824 training samples · 206 held-out test samples · Seed: {metrics.config.seed} · Strict No-Leakage Partition
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="px-3 py-1.5 text-xs font-medium font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            {showConfig ? 'Hide Config' : 'Model Hyperparameters'}
          </button>
          <button
            onClick={() => onRetrain({ nTrees, maxDepth, testSplitRatio: testSplit, seed })}
            disabled={isTraining}
            className="px-3.5 py-1.5 text-xs font-semibold font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg flex items-center gap-1.5 transition-colors shadow-sm shadow-cyan-500/20"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isTraining ? 'animate-spin' : ''}`} />
            {isTraining ? 'Training...' : 'Retrain Model'}
          </button>
        </div>
      </div>

      {/* Hyperparameter Tuning Drawer (when open) */}
      {showConfig && (
        <form
          onSubmit={handleRetrainSubmit}
          className="p-5 rounded-xl border border-cyan-500/30 bg-slate-900/90 shadow-xl space-y-4"
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-cyan-400">
              Random Forest Hyperparameter Configuration
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Empirical optimization for Experiment No. 11
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                Number of Trees (n_estimators): <span className="text-cyan-400 font-bold">{nTrees}</span>
              </label>
              <input
                type="range"
                min="10"
                max="80"
                step="5"
                value={nTrees}
                onChange={(e) => setNTrees(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400">Ensemble bagging size</span>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                Max Tree Depth: <span className="text-cyan-400 font-bold">{maxDepth}</span>
              </label>
              <input
                type="range"
                min="5"
                max="18"
                step="1"
                value={maxDepth}
                onChange={(e) => setMaxDepth(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400">Controls tree complexity</span>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                Test Split Ratio: <span className="text-cyan-400 font-bold">{Math.round(testSplit * 100)}%</span>
              </label>
              <input
                type="range"
                min="0.1"
                max="0.3"
                step="0.05"
                value={testSplit}
                onChange={(e) => setTestSplit(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400">Held-out test validation fraction</span>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                Random Seed: <span className="text-cyan-400 font-bold">{seed}</span>
              </label>
              <input
                type="number"
                min="1"
                max="999"
                value={seed}
                onChange={(e) => setSeed(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
              <span className="text-[10px] text-slate-400">Reproducible train/test split</span>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setNTrees(45);
                setMaxDepth(11);
                setTestSplit(0.2);
                setSeed(42);
              }}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
            >
              Reset to Defaults
            </button>
            <button
              type="submit"
              disabled={isTraining}
              className="px-4 py-1.5 text-xs font-semibold font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded shadow-sm"
            >
              Apply & Retrain
            </button>
          </div>
        </form>
      )}

      {/* Model Performance Cards: R², MAE, RMSE */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 font-sans">
              Model Evaluation on Held-Out Test Data
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Evaluated on {metrics.testSampleCount} unseen concrete specimens (20% test split)
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Target Leakage: <strong className="text-emerald-400 font-normal">Strictly Prevented</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* R² Card */}
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/70 relative group hover:border-cyan-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                COEFFICIENT OF DETERMINATION
              </span>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-500/30">
                R²
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-4xl font-bold font-mono text-slate-100 tabular-nums">
                {metrics.r2.toFixed(3)}
              </span>
              <span className="text-xs font-mono text-slate-400">/ 1.000</span>
            </div>
            <p className="mt-2 text-xs text-slate-300 leading-relaxed">
              Explains <strong className="text-cyan-400">{(metrics.r2 * 100).toFixed(1)}%</strong> of the variance in concrete compressive strength using mix proportions and curing age.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
              Engineering benchmark: R² &gt; 0.75 indicates robust predictive reliability for concrete trials.
            </div>
          </div>

          {/* MAE Card */}
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/70 relative group hover:border-cyan-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                MEAN ABSOLUTE ERROR
              </span>
              <span className="text-xs font-mono text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-500/30">
                MAE
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-4xl font-bold font-mono text-slate-100 tabular-nums">
                {metrics.mae.toFixed(2)}
              </span>
              <span className="text-sm font-semibold font-mono text-blue-400">MPa</span>
            </div>
            <p className="mt-2 text-xs text-slate-300 leading-relaxed">
              On average, the model's prediction deviates by <strong className="text-blue-400">{metrics.mae.toFixed(2)} MPa</strong> from the actual measured cylinder/cube test result.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
              Civil context: Corresponds to standard batch-to-batch variation in structural ready-mix plants.
            </div>
          </div>

          {/* RMSE Card */}
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/70 relative group hover:border-cyan-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                ROOT MEAN SQUARE ERROR
              </span>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                RMSE
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-4xl font-bold font-mono text-slate-100 tabular-nums">
                {metrics.rmse.toFixed(2)}
              </span>
              <span className="text-sm font-semibold font-mono text-emerald-400">MPa</span>
            </div>
            <p className="mt-2 text-xs text-slate-300 leading-relaxed">
              Penalizes larger outliers. An RMSE of <strong className="text-emerald-400">{metrics.rmse.toFixed(2)} MPa</strong> validates safety limits across low and high-strength mix regimes.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
              Safety rule: Penalizes dangerous underestimations in structural columns and beams.
            </div>
          </div>
        </div>
      </div>

      {/* Two-Column Analytics: Measured vs Predicted & Feature Importances */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive Scatter Plot or Residual Analysis */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-slate-100 font-sans">
                {activePlotTab === 'scatter' ? 'Measured vs. Predicted Strength' : 'Residual Error Distribution'}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                {metrics.testPredictions.length} test specimens plotted in MPa
              </p>
            </div>
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => setActivePlotTab('scatter')}
                className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                  activePlotTab === 'scatter'
                    ? 'bg-slate-800 text-cyan-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Parity Plot
              </button>
              <button
                onClick={() => setActivePlotTab('residuals')}
                className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                  activePlotTab === 'residuals'
                    ? 'bg-slate-800 text-cyan-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Residuals
              </button>
            </div>
          </div>

          {/* SVG Interactive Scatter Plot */}
          <div className="relative w-full h-72 sm:h-80 bg-slate-950/60 rounded-lg border border-slate-800 p-2 overflow-hidden">
            {activePlotTab === 'scatter' ? (
              <svg viewBox="0 0 420 300" className="w-full h-full">
                {/* Grid Lines */}
                {[0, 20, 40, 60, 80].map((val) => {
                  const pos = 260 - (val / 90) * 220;
                  return (
                    <g key={val} className="text-slate-800">
                      <line x1="40" y1={pos} x2="400" y2={pos} stroke="currentColor" strokeDasharray="3 3" />
                      <line x1={40 + (val / 90) * 360} y1="40" x2={40 + (val / 90) * 360} y2="260" stroke="currentColor" strokeDasharray="3 3" />
                      <text x="32" y={pos + 4} textAnchor="end" fontSize="9" className="fill-slate-500 font-mono">
                        {val}
                      </text>
                      <text x={40 + (val / 90) * 360} y="275" textAnchor="middle" fontSize="9" className="fill-slate-500 font-mono">
                        {val}
                      </text>
                    </g>
                  );
                })}

                {/* 1:1 Parity Ideal Line (y = x) */}
                <line x1="40" y1="260" x2="400" y2="40" stroke="#06B6D4" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.6" />

                {/* Data Points */}
                {metrics.testPredictions.map((pt, idx) => {
                  const cx = 40 + (Math.min(90, Math.max(0, pt.actual)) / 90) * 360;
                  const cy = 260 - (Math.min(90, Math.max(0, pt.predicted)) / 90) * 220;
                  const isSelected = selectedPoint === pt;

                  return (
                    <circle
                      key={idx}
                      cx={cx}
                      cy={cy}
                      r={isSelected ? 5.5 : 3.5}
                      fill={isSelected ? '#F59E0B' : '#06B6D4'}
                      fillOpacity={isSelected ? 1 : 0.65}
                      stroke={isSelected ? '#FFFFFF' : '#0F172A'}
                      strokeWidth={1}
                      className="cursor-pointer transition-all hover:scale-150"
                      onMouseEnter={() => setSelectedPoint(pt)}
                    />
                  );
                })}

                {/* Axes */}
                <line x1="40" y1="260" x2="400" y2="260" stroke="#475569" strokeWidth="1.5" />
                <line x1="40" y1="40" x2="40" y2="260" stroke="#475569" strokeWidth="1.5" />

                {/* Axis Labels */}
                <text x="220" y="294" textAnchor="middle" fontSize="10" className="fill-slate-400 font-mono">
                  Actual Measured Strength (MPa)
                </text>
                <text x="14" y="150" textAnchor="middle" transform="rotate(-90 14 150)" fontSize="10" className="fill-slate-400 font-mono">
                  Predicted Strength (MPa)
                </text>
              </svg>
            ) : (
              /* Residual Plot: Residual vs Predicted */
              <svg viewBox="0 0 420 300" className="w-full h-full">
                {/* Zero error centerline */}
                <line x1="40" y1="150" x2="400" y2="150" stroke="#10B981" strokeWidth="1.5" strokeDasharray="4 4" />
                <text x="32" y="153" textAnchor="end" fontSize="9" className="fill-emerald-400 font-mono">
                  0
                </text>

                {[-15, -10, -5, 5, 10, 15].map((val) => {
                  const pos = 150 - (val / 25) * 100;
                  return (
                    <g key={val} className="text-slate-800">
                      <line x1="40" y1={pos} x2="400" y2={pos} stroke="currentColor" strokeDasharray="2 2" />
                      <text x="32" y={pos + 3} textAnchor="end" fontSize="9" className="fill-slate-500 font-mono">
                        {val}
                      </text>
                    </g>
                  );
                })}

                {metrics.testPredictions.map((pt, idx) => {
                  const cx = 40 + (Math.min(90, Math.max(0, pt.predicted)) / 90) * 360;
                  const cy = 150 - (Math.min(25, Math.max(-25, pt.residual)) / 25) * 100;
                  const isSelected = selectedPoint === pt;

                  return (
                    <circle
                      key={idx}
                      cx={cx}
                      cy={cy}
                      r={isSelected ? 5.5 : 3.5}
                      fill={pt.residual > 0 ? '#06B6D4' : '#F59E0B'}
                      fillOpacity={0.7}
                      stroke="#0F172A"
                      strokeWidth={1}
                      className="cursor-pointer transition-all hover:scale-150"
                      onMouseEnter={() => setSelectedPoint(pt)}
                    />
                  );
                })}

                <line x1="40" y1="260" x2="400" y2="260" stroke="#475569" strokeWidth="1.5" />
                <line x1="40" y1="40" x2="40" y2="260" stroke="#475569" strokeWidth="1.5" />
                <text x="220" y="294" textAnchor="middle" fontSize="10" className="fill-slate-400 font-mono">
                  Predicted Strength (MPa)
                </text>
                <text x="14" y="150" textAnchor="middle" transform="rotate(-90 14 150)" fontSize="10" className="fill-slate-400 font-mono">
                  Residual Error: e = y - ŷ (MPa)
                </text>
              </svg>
            )}

            {/* Hover details HUD */}
            {selectedPoint && (
              <div className="absolute top-3 right-3 bg-slate-900/95 border border-cyan-500/40 rounded-lg p-2.5 text-xs font-mono shadow-xl space-y-1">
                <div className="text-[10px] text-slate-400 uppercase">Selected Specimen Point</div>
                <div>Actual: <strong className="text-slate-100">{selectedPoint.actual} MPa</strong></div>
                <div>Predicted: <strong className="text-cyan-400">{selectedPoint.predicted} MPa</strong></div>
                <div>Residual: <strong className={selectedPoint.residual >= 0 ? 'text-emerald-400' : 'text-amber-400'}>{selectedPoint.residual > 0 ? `+${selectedPoint.residual}` : selectedPoint.residual} MPa</strong></div>
              </div>
            )}
          </div>

          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Dashed Cyan Line: 1:1 Perfect Parity (y = ŷ)</span>
            <span>Tight clustering along line indicates high model fidelity</span>
          </div>
        </div>

        {/* Right Column: Feature Importances */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-slate-100 font-sans">
                Feature Importance (Mean Decrease in Impurity)
              </h3>
              <span className="text-xs font-mono text-cyan-400">Total: 100%</span>
            </div>
            <p className="text-xs text-slate-400 mt-2 mb-4">
              Relative contribution of each mix ingredient and curing age to predicting compressive strength:
            </p>

            <div className="space-y-3">
              {metrics.featureImportances.map((f) => {
                const pct = Math.round(f.importance * 100);
                return (
                  <div key={f.key} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-300 font-medium">{f.label}</span>
                      <span className="text-cyan-400 font-bold">{pct}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 leading-relaxed">
            <strong className="text-slate-200">Civil Engineering Finding:</strong> Cement content and curing age dominate early and ultimate strength, followed by mixing water and blast furnace slag replacement.
          </div>
        </div>
      </div>

      {/* Latest Prediction Summary Banner or CTA */}
      {latestPrediction ? (
        <div className="p-4 rounded-xl border border-cyan-500/30 bg-cyan-950/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center font-mono font-bold text-cyan-400 text-base">
              {latestPrediction.predictedStrength.toFixed(1)}
            </div>
            <div>
              <span className="text-xs font-mono uppercase text-cyan-400 font-semibold">
                Latest Calculated Mix: {latestPrediction.concreteGrade}
              </span>
              <p className="text-xs text-slate-300 font-mono">
                Water/Binder: {latestPrediction.waterToBinderRatio} · Total Binder: {latestPrediction.totalBinder} kg/m³ · Curing: {latestPrediction.input.age} days
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('predictor')}
            className="px-4 py-2 text-xs font-mono font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg flex items-center gap-1.5 transition-colors shrink-0"
          >
            Open in Predictor Studio
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="p-5 rounded-xl border border-dashed border-slate-800 bg-slate-950/40 text-center space-y-2">
          <p className="text-xs text-slate-400 font-mono">
            No live predictions generated yet. Head over to the Strength Predictor to test custom mix parameters.
          </p>
          <button
            onClick={() => onNavigate('predictor')}
            className="px-4 py-2 text-xs font-mono font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg inline-flex items-center gap-1.5 transition-colors"
          >
            Launch Prediction Studio
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
