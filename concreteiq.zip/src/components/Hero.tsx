import React from 'react';
import { ArrowRight, BarChart3, Cpu, Sparkles, BookOpen } from 'lucide-react';
import { NavTab } from './Navbar';
import { GaugeComponent } from './GaugeComponent';
import { PredictionResult } from '../types/concrete';

interface HeroProps {
  onNavigate: (tab: NavTab) => void;
  latestPrediction: PredictionResult | null;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate, latestPrediction }) => {
  return (
    <section className="relative overflow-hidden border-b border-slate-800 bg-slate-950/60 bg-eng-grid pt-10 pb-16">
      {/* Subtle radial glow in background */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-cyan-500/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Academic Course Banner */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-xs font-mono text-cyan-400 bg-cyan-950/50 border border-cyan-500/30 px-2.5 py-1 rounded">
            B.Tech Civil Engineering
          </span>
          <span className="text-xs text-slate-400 font-mono">
            Data Analytics Laboratory · Experiment No. 11
          </span>
        </div>

        {/* Main 2-Column Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7 flex flex-col items-start">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-100 font-sans leading-[1.1] max-w-2xl text-balance">
              Build Smarter.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400">
                Predict Stronger.
              </span>
            </h1>

            <p className="mt-5 text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl">
              Turn concrete mix data into actionable engineering insights with machine learning. Analyze 1,030 real test specimens from the UCI repository, evaluate 8 mix parameters, and forecast compressive strength in seconds.
            </p>

            {/* CTAs */}
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('predictor')}
                className="px-5 py-3 text-sm font-semibold font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-lg shadow-cyan-500/25 flex items-center gap-2 transition-all hover:translate-y-[-1px]"
              >
                Predict Concrete Strength
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('explorer')}
                className="px-5 py-3 text-sm font-medium text-slate-200 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-lg flex items-center gap-2 transition-colors"
              >
                <BarChart3 className="w-4 h-4 text-cyan-400" />
                Explore the Data
              </button>
            </div>

            {/* Quick stats inline strip */}
            <div className="mt-10 pt-6 border-t border-slate-800/80 flex items-center gap-6 sm:gap-10 text-xs text-slate-400 font-mono">
              <div>
                <span className="block text-xl font-bold text-slate-100 font-mono tabular-nums">1,030</span>
                <span>UCI Specimens</span>
              </div>
              <div className="w-px h-8 bg-slate-800" />
              <div>
                <span className="block text-xl font-bold text-slate-100 font-mono tabular-nums">8</span>
                <span>Mix Variables</span>
              </div>
              <div className="w-px h-8 bg-slate-800" />
              <div>
                <span className="block text-xl font-bold text-cyan-400 font-mono tabular-nums">Random Forest</span>
                <span>Ensemble Regressor</span>
              </div>
            </div>
          </div>

          {/* Right Column: Concrete Specimen Cube Visual + Live/Illustrative Gauge HUD */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur p-6 shadow-2xl overflow-hidden">
              {/* Technical Grid Overlay */}
              <div className="absolute inset-0 bg-eng-grid-dense opacity-40 pointer-events-none" />

              {/* Header inside HUD */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800 relative z-10">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-sm bg-cyan-400 shadow-sm shadow-cyan-400/50" />
                  <span className="text-xs font-mono font-semibold text-slate-200">
                    SPECIMEN TEST CHAMBER
                  </span>
                </div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                  150 mm Cube · ASTM C39 / IS 516
                </span>
              </div>

              {/* Specimen Visual with Technical Blueprint Callouts */}
              <div className="relative rounded-lg overflow-hidden border border-slate-800 mb-6 group">
                <img
                  src="/src/assets/images/concrete_specimen_cube_1791880046383.jpg"
                  alt="Standard 150mm cast concrete test cube with realistic aggregate texture on engineering slate surface"
                  className="w-full h-48 sm:h-56 object-cover object-center group-hover:scale-102 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Technical dimension overlay */}
                <div className="absolute top-2 left-2 bg-slate-950/80 backdrop-blur text-[10px] font-mono text-cyan-300 px-2 py-0.5 rounded border border-cyan-500/20">
                  Dim: 150 × 150 × 150 mm
                </div>
                <div className="absolute bottom-2 right-2 bg-slate-950/80 backdrop-blur text-[10px] font-mono text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                  Density: ~2,410 kg/m³
                </div>
              </div>

              {/* Compressive Strength Gauge */}
              <div className="relative z-10 pt-2 flex flex-col items-center">
                {latestPrediction ? (
                  <GaugeComponent
                    value={latestPrediction.predictedStrength}
                    uncertainty={latestPrediction.uncertaintyStd}
                    grade={latestPrediction.concreteGrade}
                    label="LATEST ML PREDICTION"
                    subLabel={`w/b: ${latestPrediction.waterToBinderRatio} · Age: ${latestPrediction.input.age}d`}
                    isIllustrative={false}
                  />
                ) : (
                  <GaugeComponent
                    value={38.5}
                    uncertainty={4.2}
                    grade="M35 Structural Grade"
                    label="CALIBRATED BENCHMARK"
                    subLabel="Run predictor to evaluate custom mix"
                    isIllustrative={true}
                  />
                )}
              </div>

              {/* Interactive footer action */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Model Engine: Random Forest</span>
                <button
                  onClick={() => onNavigate('predictor')}
                  className="text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1"
                >
                  Configure Parameters →
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Strip below Hero */}
        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            onClick={() => onNavigate('predictor')}
            className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-cyan-500/40 hover:bg-slate-900 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Cpu className="w-4 h-4" />
            </div>
            <h2 className="text-sm font-semibold text-slate-100 group-hover:text-cyan-400 transition-colors">
              AI Prediction Studio
            </h2>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">
              Real Random Forest inference across 8 materials parameters with 95% uncertainty intervals.
            </p>
          </div>

          <div
            onClick={() => onNavigate('overview')}
            className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-cyan-500/40 hover:bg-slate-900 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded bg-blue-950 text-blue-400 border border-blue-500/30 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <BarChart3 className="w-4 h-4" />
            </div>
            <h2 className="text-sm font-semibold text-slate-100 group-hover:text-blue-400 transition-colors">
              Model Analytics
            </h2>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">
              Real R², MAE, and RMSE metrics on held-out test data, residual analysis, and feature importances.
            </p>
          </div>

          <div
            onClick={() => onNavigate('mix-design')}
            className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-cyan-500/40 hover:bg-slate-900 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <BookOpen className="w-4 h-4" />
            </div>
            <h2 className="text-sm font-semibold text-slate-100 group-hover:text-emerald-400 transition-colors">
              Mix Design Heuristics
            </h2>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">
              Investigate water demand and superplasticizer dosages grounded in IS 10262 and ACI guidelines.
            </p>
          </div>

          <div
            onClick={() => onNavigate('assistant')}
            className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-cyan-500/40 hover:bg-slate-900 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 rounded bg-purple-950 text-purple-400 border border-purple-500/30 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-sm font-semibold text-slate-100 group-hover:text-purple-400 transition-colors">
              Engineering Assistant
            </h2>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">
              Ask ConcreteIQ about hydration reactions, admixture dosage, error metrics, or testing standards.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
