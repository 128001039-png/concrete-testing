import React, { useState } from 'react';
import { MixInput, PredictionResult, FeatureKey } from '../types/concrete';
import { FEATURE_METADATA, MIX_PRESETS } from '../utils/featureMetadata';
import { GaugeComponent } from './GaugeComponent';
import { NavTab } from './Navbar';
import { Play, RotateCcw, BookmarkPlus, Info, Check, Sparkles } from 'lucide-react';

interface StrengthPredictorProps {
  onPredict: (input: MixInput) => Promise<PredictionResult>;
  onSaveToHistory: (result: PredictionResult, name: string, notes?: string) => void;
  onNavigate: (tab: NavTab) => void;
  initialPrediction: PredictionResult | null;
}

export const StrengthPredictor: React.FC<StrengthPredictorProps> = ({
  onPredict,
  onSaveToHistory,
  onNavigate,
  initialPrediction,
}) => {
  const [inputs, setInputs] = useState<MixInput>({
    cement: 320,
    slag: 0,
    flyAsh: 0,
    water: 185,
    superplasticizer: 2.5,
    coarseAggregate: 1020,
    fineAggregate: 780,
    age: 28,
  });

  const [activePreset, setActivePreset] = useState<string>('Standard M25 Structural Mix');
  const [activeTooltip, setActiveTooltip] = useState<FeatureKey | null>(null);
  const [isPredicting, setIsPredicting] = useState<boolean>(false);
  const [result, setResult] = useState<PredictionResult | null>(initialPrediction);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [mixName, setMixName] = useState<string>('Mix Trial A');
  const [validationError, setValidationError] = useState<string | null>(null);

  // Quick preset loader
  const handleSelectPreset = (presetName: string) => {
    const preset = MIX_PRESETS.find((p) => p.name === presetName);
    if (preset) {
      setInputs({ ...preset.input });
      setActivePreset(preset.name);
      setMixName(preset.name);
      setValidationError(null);
    }
  };

  // Change single parameter
  const handleChange = (key: FeatureKey, val: number) => {
    setInputs((prev) => ({ ...prev, [key]: val }));
    setActivePreset('');
    setValidationError(null);
  };

  // Run prediction
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (inputs.cement <= 0) {
      setValidationError('Cement content must be greater than zero.');
      return;
    }
    if (inputs.water <= 50) {
      setValidationError('Water content must be realistic (> 50 kg/m³).');
      return;
    }

    setIsPredicting(true);
    setValidationError(null);
    try {
      // Simulate real calculation latency of 150ms for smooth interaction feedback
      await new Promise((r) => setTimeout(r, 150));
      const pred = await onPredict(inputs);
      setResult(pred);
    } catch (err: any) {
      setValidationError(err.message || 'Error executing prediction.');
    } finally {
      setIsPredicting(false);
    }
  };

  const handleReset = () => {
    setInputs({
      cement: 280,
      slag: 120,
      flyAsh: 0,
      water: 180,
      superplasticizer: 6.0,
      coarseAggregate: 980,
      fineAggregate: 750,
      age: 28,
    });
    setActivePreset('');
    setValidationError(null);
  };

  const handleSave = () => {
    if (result) {
      onSaveToHistory(result, mixName || 'Custom Mix', `w/b = ${result.waterToBinderRatio}, age = ${result.input.age}d`);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    }
  };

  // Dynamic live mix indicators
  const totalBinder = inputs.cement + inputs.slag + inputs.flyAsh;
  const wbRatio = totalBinder > 0 ? (inputs.water / totalBinder).toFixed(2) : '0.00';
  const wcRatio = inputs.cement > 0 ? (inputs.water / inputs.cement).toFixed(2) : '0.00';
  const totalAgg = inputs.coarseAggregate + inputs.fineAggregate;
  const fineRatio = totalAgg > 0 ? Math.round((inputs.fineAggregate / totalAgg) * 100) : 0;
  const estimatedMass = Math.round(totalBinder + inputs.water + inputs.superplasticizer + totalAgg);

  return (
    <div className="space-y-8">
      {/* Header & Presets Bar */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-100 font-sans">
              Concrete Strength Prediction Studio
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Adjust 8 material inputs to calculate 28-day / early-age compressive strength via Random Forest
            </p>
          </div>
          <button
            onClick={handleReset}
            className="self-start sm:self-auto px-3 py-1.5 text-xs font-mono text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Parameters
          </button>
        </div>

        {/* Mix Presets Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <span className="text-xs font-mono text-slate-400 shrink-0">Presets:</span>
          {MIX_PRESETS.map((preset) => (
            <button
              key={preset.name}
              onClick={() => handleSelectPreset(preset.name)}
              className={`px-3 py-1 text-xs font-mono rounded-md whitespace-nowrap shrink-0 transition-colors ${
                activePreset === preset.name
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {preset.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main 2-Column Split: Controls on Left, HUD Readout on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (7 cols): Parameter Inputs */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {validationError && (
              <div className="p-3 text-xs font-mono text-rose-400 bg-rose-950/40 border border-rose-500/30 rounded-lg">
                Validation Warning: {validationError}
              </div>
            )}

            {/* Feature Sliders & Number Fields */}
            <div className="space-y-5">
              {(Object.keys(FEATURE_METADATA) as FeatureKey[]).map((key) => {
                const meta = FEATURE_METADATA[key];
                const val = inputs[key];

                return (
                  <div key={key} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5">
                        <label className="font-semibold text-slate-200 font-sans">
                          {meta.label}
                        </label>
                        <button
                          type="button"
                          onClick={() => setActiveTooltip(activeTooltip === key ? null : key)}
                          className="text-slate-500 hover:text-cyan-400 transition-colors"
                          title="View material explanation"
                        >
                          <Info className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min={meta.min}
                          max={meta.max}
                          step={meta.step}
                          value={val}
                          onChange={(e) => handleChange(key, Number(e.target.value))}
                          className="w-20 px-2 py-1 text-right text-xs font-mono font-bold bg-slate-950 border border-slate-700 rounded text-cyan-400 focus:outline-none focus:border-cyan-400"
                        />
                        <span className="text-[11px] font-mono text-slate-400 w-12 text-left">
                          {meta.unit}
                        </span>
                      </div>
                    </div>

                    {/* Slider Rail */}
                    <input
                      type="range"
                      min={meta.min}
                      max={meta.max}
                      step={meta.step}
                      value={val}
                      onChange={(e) => handleChange(key, Number(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-950 rounded-lg"
                    />

                    {/* Optional Inline Tooltip */}
                    {activeTooltip === key && (
                      <div className="p-2.5 rounded bg-slate-950/90 border border-cyan-500/30 text-[11px] text-slate-300 space-y-1 animate-fadeIn">
                        <div className="text-cyan-400 font-mono font-semibold">
                          Engineering Role: {meta.engineeringRole}
                        </div>
                        <div className="text-slate-400 leading-relaxed">
                          {meta.description} (Range: {meta.min} - {meta.max} {meta.unit})
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Live Mix Composition Metrics */}
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500 block text-[10px]">W/C RATIO</span>
                <span className="text-sm font-bold text-slate-100">{wcRatio}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">W/B RATIO</span>
                <span className="text-sm font-bold text-cyan-400">{wbRatio}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">TOTAL BINDER</span>
                <span className="text-sm font-bold text-slate-100">{totalBinder} kg/m³</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">EST. DENSITY</span>
                <span className="text-sm font-bold text-emerald-400">~{estimatedMass} kg/m³</span>
              </div>
            </div>

            {/* Run Prediction Button */}
            <button
              type="submit"
              disabled={isPredicting}
              className="w-full py-3.5 px-4 text-sm font-bold font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <Play className={`w-4 h-4 ${isPredicting ? 'animate-spin' : ''}`} />
              {isPredicting ? 'Executing Random Forest Inference...' : 'Predict Compressive Strength'}
            </button>
          </form>
        </div>

        {/* Right Column (5 cols): Prediction Results & Gauge HUD */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-slate-900/80 p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-300">
              PREDICTIVE ANALYSIS OUTPUT
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
              Live Evaluation
            </span>
          </div>

          {result ? (
            <div className="space-y-6">
              {/* Gauge */}
              <div className="pt-2 flex justify-center">
                <GaugeComponent
                  value={result.predictedStrength}
                  uncertainty={result.uncertaintyStd}
                  grade={result.concreteGrade}
                  label="PREDICTED COMPRESSIVE STRENGTH"
                  subLabel={`Curing Age: ${result.input.age} Days`}
                  isIllustrative={false}
                />
              </div>

              {/* 95% Confidence Interval Banner */}
              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">95% Prediction Interval:</span>
                  <span className="text-cyan-400 font-bold">
                    {result.lower95} — {result.upper95} MPa
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Estimated Workability:</span>
                  <span className="text-slate-200">{result.slumpEstimate}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Fine/Total Aggregate:</span>
                  <span className="text-slate-200">{result.fineAggregateRatio}%</span>
                </div>
              </div>

              {/* Engineering Limitations Notice */}
              <div className="p-3 rounded-lg border border-amber-500/20 bg-amber-500/5 text-slate-300 text-[11px] leading-relaxed">
                <strong className="text-amber-400 font-mono">Uncertainty Notice:</strong> Predictions reflect empirical Random Forest regressions trained on 1,030 specimens. Real-world compressive strength depends heavily on batching precision, moisture corrections, vibration compaction, and water curing conditions.
              </div>

              {/* Save to History Actions */}
              <div className="pt-2 border-t border-slate-800 space-y-3">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={mixName}
                    onChange={(e) => setMixName(e.target.value)}
                    placeholder="Mix identifier / Trial name"
                    className="flex-1 px-3 py-1.5 text-xs font-mono bg-slate-950 border border-slate-700 rounded text-slate-100"
                  />
                  <button
                    onClick={handleSave}
                    className="px-3.5 py-1.5 text-xs font-mono font-medium text-slate-100 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 flex items-center gap-1.5 transition-colors"
                  >
                    {saveSuccess ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        Saved!
                      </>
                    ) : (
                      <>
                        <BookmarkPlus className="w-3.5 h-3.5 text-cyan-400" />
                        Save to History
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <button
                    onClick={() => onNavigate('explorer')}
                    className="text-cyan-400 hover:text-cyan-300 hover:underline font-mono"
                  >
                    Explore Similar Mixes in Dataset →
                  </button>
                  <button
                    onClick={() => onNavigate('history')}
                    className="text-slate-400 hover:text-slate-200 hover:underline font-mono"
                  >
                    View History
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-800/80 flex items-center justify-center text-slate-500">
                <Sparkles className="w-6 h-6" />
              </div>
              <p className="text-xs text-slate-400 font-mono max-w-xs">
                Configure mix parameters and click &ldquo;Predict Compressive Strength&rdquo; to execute the model.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
