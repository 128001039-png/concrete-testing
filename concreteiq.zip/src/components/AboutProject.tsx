import React, { useState } from 'react';
import { Edit2, Check, ExternalLink, ShieldAlert, Cpu } from 'lucide-react';

export const AboutProject: React.FC = () => {
  // Editable student details for viva/demonstration
  const [isEditing, setIsEditing] = useState(false);
  const [studentDetails, setStudentDetails] = useState({
    studentName: 'Student Researcher',
    rollNumber: '128001039',
    batch: 'Batch B · Final Year',
    course: 'B.Tech Civil Engineering',
    labCourse: 'Data Analytics for Civil Engineering Laboratory',
    experimentNo: 'Experiment No. 11: Machine Learning Analytics for Concrete Compressive Strength',
    facultyGuide: 'Dr. Faculty Supervisor, Structural Engineering Division',
    academicYear: '2025 – 2026',
  });

  const handleSaveDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditing(false);
  };

  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-2.5 py-1 rounded">
            Experiment No. 11
          </span>
          <span className="text-xs font-mono text-slate-400">
            Civil Engineering Data Analytics Lab Report
          </span>
        </div>
        <h2 className="text-2xl font-bold text-slate-100 font-sans">
          About Project &amp; Machine Learning Methodology
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-1">
          CONCRETEIQ: AI-Powered Predictive Analytics for High-Performance Concrete Mix Formulations
        </p>
      </div>

      {/* Editable Student & Lab Metadata Card */}
      <div className="rounded-xl border border-cyan-500/30 bg-slate-900/80 p-6 shadow-xl relative">
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold font-mono text-slate-100 uppercase tracking-wider">
              Laboratory Project Dossier &amp; Student Credentials
            </h3>
          </div>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors"
          >
            {isEditing ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Done Editing</span>
              </>
            ) : (
              <>
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit Details for Demo</span>
              </>
            )}
          </button>
        </div>

        {isEditing ? (
          <form onSubmit={handleSaveDetails} className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div>
              <label className="block text-slate-400 mb-1">Student Name:</label>
              <input
                type="text"
                value={studentDetails.studentName}
                onChange={(e) => setStudentDetails({ ...studentDetails, studentName: e.target.value })}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Roll / Register Number:</label>
              <input
                type="text"
                value={studentDetails.rollNumber}
                onChange={(e) => setStudentDetails({ ...studentDetails, rollNumber: e.target.value })}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Laboratory Batch:</label>
              <input
                type="text"
                value={studentDetails.batch}
                onChange={(e) => setStudentDetails({ ...studentDetails, batch: e.target.value })}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Faculty Supervisor:</label>
              <input
                type="text"
                value={studentDetails.facultyGuide}
                onChange={(e) => setStudentDetails({ ...studentDetails, facultyGuide: e.target.value })}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Degree Program:</label>
              <input
                type="text"
                value={studentDetails.course}
                onChange={(e) => setStudentDetails({ ...studentDetails, course: e.target.value })}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Academic Year:</label>
              <input
                type="text"
                value={studentDetails.academicYear}
                onChange={(e) => setStudentDetails({ ...studentDetails, academicYear: e.target.value })}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100"
              />
            </div>
            <div className="sm:col-span-2 flex justify-end pt-2">
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold rounded"
              >
                Save Details
              </button>
            </div>
          </form>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">CANDIDATE</span>
              <span className="text-sm font-bold text-slate-100">{studentDetails.studentName}</span>
              <span className="text-slate-400 block mt-0.5">Reg No: {studentDetails.rollNumber}</span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase">LAB EXPERIMENT</span>
              <span className="text-sm font-bold text-cyan-400">{studentDetails.batch}</span>
              <span className="text-slate-400 block mt-0.5">{studentDetails.experimentNo}</span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase">FACULTY &amp; INSTITUTION</span>
              <span className="text-sm font-bold text-slate-100">{studentDetails.facultyGuide}</span>
              <span className="text-slate-400 block mt-0.5">{studentDetails.course} · {studentDetails.academicYear}</span>
            </div>
          </div>
        )}
      </div>

      {/* Laboratory Visual Spotlight */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden grid grid-cols-1 md:grid-cols-12 items-center">
        <div className="md:col-span-5 h-64 md:h-full relative">
          <img
            src="/src/assets/images/concrete_lab_testing_1791880048205.jpg"
            alt="Civil engineering materials testing laboratory showing hydraulic compression testing apparatus"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-slate-950/80 via-transparent to-transparent pointer-events-none" />
        </div>
        <div className="md:col-span-7 p-6 sm:p-8 space-y-3">
          <div className="text-xs font-mono text-cyan-400 uppercase font-semibold">
            Laboratory Testing Protocol
          </div>
          <h3 className="text-lg font-bold text-slate-100 font-sans">
            Compression Testing Machine (CTM) Calibration
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            In standard laboratory verification (IS 516 / ASTM C39), concrete specimens are cast in 150 mm steel cube moulds, compacted on a vibrating table, and water-cured at 27 ± 2°C for 3, 7, 14, 28, or 56 days. Compressive failure load (kN) is measured under uniform hydraulic loading rate (140 kg/cm²/min) and divided by cross-sectional area (22,500 mm²) to obtain compressive strength in MPa.
          </p>
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-4 pt-2">
            <span>Loading Rate: 0.25 MPa/s</span>
            <span>·</span>
            <span>Mould Size: 150 × 150 × 150 mm</span>
          </div>
        </div>
      </div>

      {/* Experiment Workflow & Academic Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left: ML Workflow */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-4">
          <h3 className="text-sm font-semibold text-slate-100 font-sans flex items-center gap-2">
            <span>01. Machine Learning Analytics Workflow</span>
          </h3>
          <ol className="list-decimal list-inside space-y-2.5 text-xs text-slate-300 leading-relaxed font-sans">
            <li>
              <strong>Dataset Acquisition:</strong> Canonical UCI Concrete Compressive Strength repository donated by Prof. I-Cheng Yeh (1,030 samples).
            </li>
            <li>
              <strong>Feature Isolation:</strong> 8 continuous input variables (7 material masses in kg/m³ + curing age in days).
            </li>
            <li>
              <strong>Train/Test Partitioning:</strong> Disjoint 80% training set (824 batches) and 20% held-out test set (206 batches) with zero target leakage.
            </li>
            <li>
              <strong>Random Forest Regressor:</strong> Bootstrap aggregation (bagging) of 45-50 decision trees, optimizing mean decrease in impurity at each node split.
            </li>
            <li>
              <strong>Metric Evaluation:</strong> Calculation of held-out R², MAE, RMSE, residuals, and variance reduction feature importances.
            </li>
          </ol>
        </div>

        {/* Right: Dataset Source & Features */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-4">
          <h3 className="text-sm font-semibold text-slate-100 font-sans flex items-center gap-2">
            <span>02. UCI Dataset Reference Specification</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            The dataset is a classical civil engineering benchmark dataset compiled from experimental testing programs at Chung-Hua University, Taiwan:
          </p>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">Dataset Donor:</span>
              <span className="text-slate-200">Prof. I-Cheng Yeh (1998)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Total Specimens:</span>
              <span className="text-cyan-400 font-bold">1,030</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Input Dimensions:</span>
              <span className="text-slate-200">8 Independent Variables</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Target Range:</span>
              <span className="text-emerald-400 font-bold">2.33 — 82.60 MPa</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-slate-800 text-[11px]">
              <span className="text-slate-400">UCI Repository URL:</span>
              <a
                href="https://archive.ics.uci.edu/dataset/165/concrete+compressive+strength"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1"
              >
                archive.ics.uci.edu/dataset/165
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Mandatory Safety Notice Box */}
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-6 space-y-3">
        <div className="flex items-center gap-2 text-amber-400 font-mono font-bold text-xs uppercase tracking-wider">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span>Structural Engineering Safety Directive</span>
        </div>
        <p className="text-xs text-slate-200 leading-relaxed">
          ConcreteIQ provides educational predictions based on historical data. Model predictions are not guarantees of actual concrete performance and do not constitute an approved structural mix design. Any proposed mix must be designed and verified using applicable standards (IS 10262, IS 456, ACI 211), laboratory trial mixes, material testing, and qualified engineering judgement before practical implementation.
        </p>
      </div>
    </div>
  );
};
